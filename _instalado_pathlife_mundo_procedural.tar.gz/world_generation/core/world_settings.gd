## Configuração global do mundo procedural.
##
## É um [Resource]: crie um `.tres` em `res://data/world/` e ajuste tudo pelo
## Inspector. Nenhum sistema deve ler números mágicos direto do código.
class_name WorldSettings
extends Resource

@export_category("Semente")
## Semente mestre do mundo. 0 = sorteia uma semente ao iniciar.
@export var world_seed: int = 20260819

@export_category("Chunks")
@export_range(4, 64, 1) var chunk_size: int = 16
## Raio (em chunks) mantido carregado ao redor do jogador.
@export_range(0, 8, 1) var render_distance: int = 2
## Quantos chunks além do raio ficam vivos antes de descarregar (histerese).
@export_range(0, 4, 1) var unload_margin: int = 1
## Tamanho da região macro (em chunks) usada para planejar estruturas grandes.
@export_range(1, 32, 1) var generation_region_size_chunks: int = 4

@export_category("Projeção isométrica")
## Tamanho do losango da face superior do tile (deve bater com o TileSet).
@export var tile_size: Vector2i = Vector2i(128, 64)
## Altura em pixels de um nível de terreno (altura da lateral do bloco).
@export_range(1, 128, 1) var height_pixels: int = 26

@export_category("Limites de altura")
@export_range(-64, 0, 1) var min_height: int = -8
@export_range(0, 64, 1) var max_height: int = 14
## Altura da lâmina d'água. Células abaixo disso viram líquido.
@export_range(-64, 64, 1) var sea_level: int = 0

@export_category("Geração assíncrona")
## Quantos chunks podem ser gerados em paralelo. Também define quantas cópias
## dos recursos de geração são criadas (uma por thread, para evitar disputa).
@export_range(1, 16, 1) var max_parallel_generations: int = 4
## Quantos chunks no máximo são integrados na SceneTree por frame.
@export_range(1, 16, 1) var max_chunk_integrations_per_frame: int = 1
## Se falso, gera tudo na main thread (útil para depurar).
@export var use_worker_threads: bool = true

@export_category("Renderização")
## Profundidade máxima de parede desenhada abaixo de um bloco.
@export_range(1, 32, 1) var max_wall_depth: int = 6
## Id do tile desenhado na superfície da água (precisa existir no TileCatalog).
@export var water_ground_id: StringName = &"agua"


func resolved_seed() -> int:
	if world_seed != 0:
		return world_seed
	return int(Time.get_unix_time_from_system() * 1000.0) & 0x7FFFFFFF
