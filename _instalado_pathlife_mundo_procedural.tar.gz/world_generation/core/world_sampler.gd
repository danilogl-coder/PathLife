## Amostrador global do mundo.
##
## Concentra clima + bioma + relevo base em um único recurso, para que TODOS os
## sistemas (passes, planejador de estruturas, minimapa, debug) enxerguem
## exatamente os mesmos valores em qualquer coordenada mundial, sem depender de
## chunk. É o que garante continuidade entre chunks e determinismo.
class_name WorldSampler
extends Resource

@export var climate: ClimateGenerator
@export var biome_resolver: BiomeResolver
@export var height_generator: HeightGenerator
@export var terrain_resolver: TerrainResolver

var _settings: WorldSettings
var _world_seed: int = 0


func prepare(settings: WorldSettings, world_seed: int) -> void:
	_settings = settings
	_world_seed = world_seed
	if climate != null:
		climate.prepare(world_seed)
	if height_generator != null:
		height_generator.prepare(world_seed)


func settings() -> WorldSettings:
	return _settings


func world_seed() -> int:
	return _world_seed


func sample_climate(world_xy: Vector2i) -> ClimateSample:
	if climate == null:
		return ClimateSample.new()
	return climate.sample(world_xy)


func resolve_biome(world_xy: Vector2i) -> BiomeDefinition:
	if biome_resolver == null:
		return null
	return biome_resolver.resolve(sample_climate(world_xy)).primary


## Altura base (antes de qualquer estrutura/estrada). Determinística e global.
func base_height(world_xy: Vector2i) -> int:
	if height_generator == null or _settings == null:
		return 0
	var bias := 0.0
	var amplitude := 1.0
	var biome := resolve_biome(world_xy)
	if biome != null:
		bias = biome.height_bias
		amplitude = biome.height_amplitude
	return height_generator.to_level(
		height_generator.sample_raw(world_xy), _settings, bias, amplitude
	)


func roughness(world_xy: Vector2i) -> float:
	if height_generator == null:
		return 0.5
	return height_generator.sample_roughness(world_xy)


## Declive base considerando os 4 vizinhos cardeais (independe de chunk).
func base_slope(world_xy: Vector2i) -> float:
	var height := base_height(world_xy)
	var worst := 0
	for offset: Vector2i in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
		worst = maxi(worst, absi(base_height(world_xy + offset) - height))
	return float(worst)


## Cópia independente, para rodar em outra thread sem disputa.
##
## Atenção: `Resource.duplicate(true)` no Godot 4.4+ só copia sub-recursos
## INTERNOS (os que não têm arquivo próprio). Como aqui todos os recursos são
## arquivos `.tres`, a clonagem precisa ser explícita — é isso que este método
## faz. Biomas e terrenos continuam compartilhados de propósito: são apenas
## leitura.
func clone_for_thread() -> WorldSampler:
	var copy: WorldSampler = duplicate(false)
	if climate != null:
		copy.climate = climate.clone_for_thread()
	if height_generator != null:
		copy.height_generator = height_generator.clone_for_thread()
	copy.biome_resolver = biome_resolver
	copy.terrain_resolver = terrain_resolver
	copy.prepare(_settings, _world_seed)
	return copy
