## Representação VISUAL de um chunk. Não guarda regra de jogo.
##
## Um [TileMapLayer] por nível de altura, criado só para os níveis realmente
## usados. Cada camada é instanciada a partir de `height_layer.tscn`, então
## continua sendo um nó configurável no editor.
class_name ChunkView
extends Node2D

@export var height_layer_scene: PackedScene
@export var catalog: TileCatalog
@export var settings: WorldSettings

@onready var height_layers: Node2D = %HeightLayers
@onready var structures_root: Node2D = %Structures
@onready var decorations_root: Node2D = %Decorations

var chunk_coord: Vector2i = Vector2i.ZERO

var _layers: Dictionary = {}
var _iso: IsoCoordinateSystem


func build(chunk: ChunkData, p_settings: WorldSettings, p_catalog: TileCatalog) -> void:
	settings = p_settings
	catalog = p_catalog
	chunk_coord = chunk.coord
	_iso = IsoCoordinateSystem.from_settings(settings)

	_clear()
	_paint_ground(chunk)


func _clear() -> void:
	for layer: TileMapLayer in _layers.values():
		layer.queue_free()
	_layers.clear()
	for child in structures_root.get_children():
		child.queue_free()
	for child in decorations_root.get_children():
		child.queue_free()


func _paint_ground(chunk: ChunkData) -> void:
	var size := chunk.size
	for y in size:
		for x in size:
			var cell := chunk.get_cell(Vector2i(x, y))
			if cell == null:
				continue
			var cell_coord := Vector2i(cell.world_xy.x, cell.world_xy.y)

			# 1) bloco de topo
			_set_tile(cell.height, cell_coord, cell.ground_id)

			# 2) coluna de parede até o vizinho da frente mais baixo
			var lowest := _lowest_front_neighbor(chunk, cell)
			var depth := 0
			var level := cell.height - 1
			while level > lowest and depth < settings.max_wall_depth:
				_set_tile(level, cell_coord, cell.wall_id)
				level -= 1
				depth += 1

			# 3) superfície de água
			if cell.is_liquid():
				_set_tile(settings.sea_level, cell_coord, settings.water_ground_id)


## Vizinhos "da frente" na projeção isométrica: (x+1, y) e (x, y+1).
func _lowest_front_neighbor(chunk: ChunkData, cell: WorldCell) -> int:
	var lowest := cell.height
	for offset: Vector2i in [Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)]:
		var neighbor := chunk.get_cell_world(cell.world_xy + offset)
		if neighbor == null:
			# Fora do chunk: assume um degrau, evitando buraco visual na borda.
			lowest = mini(lowest, cell.height - 1)
		else:
			lowest = mini(lowest, neighbor.height)
	return lowest


func _set_tile(level: int, cell_coord: Vector2i, ground_id: StringName) -> void:
	if catalog == null:
		return
	var entry := catalog.find(ground_id)
	if entry == null:
		return
	_layer_for(level).set_cell(cell_coord, entry.source_id, entry.atlas_coords, entry.alternative_tile)


func _layer_for(level: int) -> TileMapLayer:
	if _layers.has(level):
		return _layers[level]
	var layer: TileMapLayer = height_layer_scene.instantiate()
	layer.name = "Height_%d" % level
	layer.tile_set = catalog.tile_set
	layer.position = _iso.height_offset(level)
	# z_index por nível: garante que blocos altos na frente cubram os baixos.
	layer.z_index = clampi(level, -4000, 4000)
	height_layers.add_child(layer)
	_layers[level] = layer
	return layer


func layer_levels() -> Array:
	return _layers.keys()


func layer_at(level: int) -> TileMapLayer:
	return _layers.get(level, null)


## Instancia uma decoração já decidida pelos dados.
func add_decoration(placement: DecorationPlacement) -> Node2D:
	if placement.definition == null or placement.definition.scene == null:
		return null
	var instance: Node2D = placement.definition.scene.instantiate()
	instance.position = _iso.world_to_local(placement.world_pos)
	instance.z_index = clampi(placement.world_pos.z, -4000, 4000)
	instance.scale = Vector2(
		-placement.scale_factor if placement.flip_h else placement.scale_factor,
		placement.scale_factor
	)
	instance.set_meta(&"object_id", placement.object_id)
	instance.set_meta(&"world_position", placement.world_pos)
	decorations_root.add_child(instance)
	return instance


## Instancia uma estrutura já planejada.
func add_structure(placement: StructurePlacement) -> Node2D:
	if placement.definition == null or placement.definition.scene == null:
		return null
	var instance: Node2D = placement.definition.scene.instantiate()
	instance.position = _iso.world_to_local(
		Vector3i(placement.origin_xy.x, placement.origin_xy.y, placement.foundation_height)
	)
	instance.z_index = clampi(placement.foundation_height, -4000, 4000)
	var root := instance as StructureRoot
	if root != null:
		root.setup(placement)
	structures_root.add_child(instance)
	return instance


## Usado pelo [HeightVisibilityManager]. Não altera dados, só aparência.
func apply_level_modulation(level: int, color: Color, layer_visible: bool) -> void:
	var layer: TileMapLayer = _layers.get(level, null)
	if layer == null:
		return
	layer.visible = layer_visible
	layer.modulate = color
