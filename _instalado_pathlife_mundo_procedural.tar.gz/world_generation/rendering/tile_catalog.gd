## Catálogo que traduz ids lógicos em coordenadas do TileSet.
##
## É aqui — e só aqui — que "dado" vira "tile". Trocar a arte do mundo inteiro
## significa trocar este `.tres`, sem tocar em geração, IA ou save.
class_name TileCatalog
extends Resource

@export var tile_set: TileSet
@export var entries: Array[GroundTileEntry] = []
## Usado quando um id não está catalogado (evita mundo invisível por engano).
@export var fallback_ground_id: StringName = &"terra"

var _lookup: Dictionary = {}


func _ensure_lookup() -> void:
	if not _lookup.is_empty():
		return
	for entry in entries:
		if entry != null:
			_lookup[entry.ground_id] = entry


func find(ground_id: StringName) -> GroundTileEntry:
	_ensure_lookup()
	if _lookup.has(ground_id):
		return _lookup[ground_id]
	if _lookup.has(fallback_ground_id):
		return _lookup[fallback_ground_id]
	return null


func has(ground_id: StringName) -> bool:
	_ensure_lookup()
	return _lookup.has(ground_id)


func rebuild() -> void:
	_lookup.clear()
	_ensure_lookup()
