# Tutorial — Mexendo no mundo procedural do PathLife

Este documento é o "manual do operador". Ele responde três perguntas:
**como adicionar um bioma**, **como adicionar uma estrutura** e **como adicionar
uma mecânica nova** — sem tocar no núcleo.

> Regra de ouro do módulo: se você precisou editar um arquivo dentro de
> `world_generation/core/`, `chunks/` ou `rendering/` para adicionar
> **conteúdo**, provavelmente existe um caminho melhor. Conteúdo entra como
> `.tres` + `.tscn`. Comportamento novo entra como um passe novo.

---

## 0. Onde está cada coisa

```text
res://
├── assets/world/            arte (atlas de chão, árvores, piso de madeira)
├── data/world/              TODOS os .tres de configuração
│   ├── world_settings.tres      ← comece por aqui
│   ├── world_generator.tres     ← a pipeline (lista de passes)
│   ├── world_sampler.tres       ← clima + bioma + relevo
│   ├── biomes/  terrains/  decorations/  structures/  passes/  noise/
│   └── tiles/ground_tileset.tres + ground_catalog.tres
├── presentation/world/      cenas visuais (árvores, estruturas)
├── scenes/world/            procedural_world.tscn e world_demo.tscn
├── world_generation/        os scripts
└── tools/build_world_resources.gd   recria os .tres do zero
```

**Para ver o mundo agora:** abra `res://scenes/world/world_demo.tscn` e aperte
**F6**. WASD anda, Shift corre. O canto superior esquerdo mostra célula, altura,
bioma, relevo e quantos chunks estão carregados.

---

## 1. Os 8 botões que você vai mexer primeiro

Abra `res://data/world/world_settings.tres` no Inspector.

| Propriedade | O que muda |
|---|---|
| `world_seed` | A semente. `0` = mundo aleatório a cada partida. |
| `chunk_size` | Células por chunk (padrão 16). Maior = menos chunks, cada um mais caro. |
| `render_distance` | Raio de chunks carregados (padrão 2 → 5×5). |
| `height_pixels` | **Não mexa sem trocar a arte.** 26 px = altura da saia do bloco. |
| `min_height` / `max_height` | Amplitude vertical do mundo. |
| `sea_level` | Altura da lâmina d'água. |
| `max_parallel_generations` | Chunks gerados em paralelo. |
| `use_worker_threads` | Desligue para depurar a geração na main thread. |

Para relevo mais dramático ou mais manso, abra
`res://data/world/height_generator.tres` e mexa em:

* `contrast` (padrão 3.2) — o botão mais eficaz. Mais alto = montanhas e vales
  mais extremos;
* `continent_scale` / `elevation_scale` / `mountain_scale` — tamanho das formas;
* `continent_weight` / `elevation_weight` / `mountain_weight` / `detail_weight`;
* `mountain_sharpness` — quanto maior, picos mais raros e afiados.

E em `res://data/world/climate_generator.tres`:

* `biome_scale` (padrão 420) — **tamanho dos biomas** em células;
* `contrast` (padrão 2.3) — sem ele os climas ficam presos perto de 0.5 e
  deserto/neve/montanha nunca aparecem.

---

## 2. Adicionar um bioma novo

Exemplo: um bioma **"cerrado"**, quente e semiárido.

### Passo 1 — arte do chão (se for um chão novo)

O atlas `res://assets/world/tiles/ground_atlas.png` é uma grade de células
**128×106**: 3 colunas (os 3 frames da animação) × N linhas (os tipos de chão).

1. Aumente a altura da imagem em 106 px e desenhe os 3 frames na linha nova.
   Mantenha a geometria: losango de topo de 128×64 começando em `y = 16` e saia
   de 26 px abaixo.
2. Abra `res://data/world/tiles/ground_catalog.tres`, no array `entries`
   adicione um `GroundTileEntry`:
   * `ground_id = &"cerrado"`
   * `source_id = 0`
   * `atlas_coords = Vector2i(0, 12)` (a linha nova)
3. Abra `res://data/world/tiles/ground_tileset.tres`, selecione o atlas e
   registre o tile em `(0, 12)` com **Animation Columns = 3**, **3 frames** e
   **Texture Origin = (0, −5)**.

Se o bioma reaproveitar um chão existente, pule este passo inteiro.

### Passo 2 — o `.tres` do bioma

`Botão direito em data/world/biomes/ → New Resource → BiomeDefinition`,
salve como `cerrado.tres` e preencha:

| Campo | Valor de exemplo | Observação |
|---|---|---|
| `id` | `cerrado` | Único. É por ele que tudo se refere ao bioma. |
| `temperature_min/max` | 0.62 / 0.88 | 0 = gelado, 1 = escaldante. |
| `humidity_min/max` | 0.18 / 0.42 | 0 = seco, 1 = encharcado. |
| `continentalness_min/max` | 0.34 / 1.0 | Abaixo de ~0.24 é oceano. |
| `transition_width` | 0.12 | Largura da mistura com os vizinhos. |
| `weight` | 1.0 | Suba para o bioma "ganhar" as disputas. |
| `ground_id` | `cerrado` | Precisa existir no `TileCatalog`. |
| `wall_id` | `terra` | O que aparece nos desníveis. |
| `underwater_ground_id` | `lama` | Fundo quando submerso. |
| `height_bias` | 0.5 | Desloca o relevo em níveis. |
| `height_amplitude` | 0.9 | Multiplica a amplitude local. |
| `decorations` | `[baoba.tres, ipe.tres]` | Vegetação. |
| `structure_pool` | `[]` | Estruturas permitidas aqui. |

### Passo 3 — registrar

Abra `res://data/world/biome_resolver.tres` e arraste `cerrado.tres` para o
array `biomes`. **Pronto. Nenhuma linha de código.**

### Como o resolver escolhe

Cada bioma recebe uma nota:

```
nota = faixa(temperatura) × faixa(umidade) × faixa(continentalidade) × weight
```

`faixa()` vale 1.0 dentro do intervalo e cai suavemente até 0 ao longo de
`transition_width`. O bioma de maior nota vence; o segundo colocado é guardado
em `secondary_biome_id` com o peso em `biome_blend` — é isso que permite
transições graduais e que a vegetação rareie perto da fronteira
(`DecorationDefinition.max_biome_blend`).

### Conferindo

Rode `godot --headless --path . --script res://tests/world_generation_test.gd`.
O teste "biomas alcançáveis" varre o espaço climático inteiro e diz quantos
biomas realmente aparecem. Se o seu não aparecer, as faixas estão fora do
alcance do ruído — aumente `climate_generator.contrast` ou alargue o intervalo.

### Biomas que já existem

`oceano`, `praia`, `deserto`, `savana`, `campo`, `campo_florido`, `floresta`,
`pantano`, `planalto_claro`, `tundra`, `neve`, `montanha_rochosa`.

---

## 3. Adicionar uma estrutura (casa, loja, hospital…)

Estrutura = **uma cena normal do Godot** + **um `.tres` de regras**.

### Passo 1 — desenhe a cena

`res://presentation/world/structures/minha_casa.tscn`

```text
MinhaCasa            (Node2D, script structure_root.gd, Y-Sort ligado)
├── Piso             (Node2D, Y-Sort)
│   └── Sprite2D...  (ou uma TileMapLayer com o TileSet da casa)
├── Paredes
├── Mobilia
└── Marcadores
    ├── EntranceMarker   (Marker2D + structure_marker.gd, tipo ENTRANCE)
    ├── RoadMarker       (tipo ROAD)
    └── NPCSpawnMarker   (tipo NPC_SPAWN)
```

Use `res://presentation/world/structures/deck_madeira.tscn` como ponto de
partida — ele já tem a estrutura acima.

Dicas de posicionamento: a origem da cena é o **centro da face superior da
célula (0,0) do footprint**. A célula `(i, j)` fica em
`Vector2((i - j) * 64, (i + j) * 32)` relativa a essa origem.

No Inspector da raiz, ligue `draw_footprint_gizmo` e ajuste `footprint_preview`
para o tamanho em células: o editor desenha o losango do footprint para você
alinhar paredes e móveis.

### Passo 2 — o `.tres` de regras

`New Resource → StructureDefinition`, salve em `data/world/structures/`:

| Grupo | Campo | Para que serve |
|---|---|---|
| — | `scene` | A `.tscn` acima. |
| Footprint | `footprint` | Área em células (ex.: `Vector2i(6, 5)`). |
| | `adaptation_margin` | Quantas células ao redor o terreno mistura (5–8 fica natural). |
| Spawn | `spawn_chance` | Probabilidade por tentativa da região. |
| | `spawn_weight` | Peso na disputa contra outras estruturas do bioma. |
| | `minimum_spacing` | Distância mínima até outra estrutura, em células. |
| | `allowed_biomes` | Vazio = qualquer bioma. |
| | `allowed_terrains` | Vazio = qualquer relevo. Ex.: `[plano, colina]`. |
| | `min/max_world_height` | Faixa de altitude. |
| | `max_slope` | Desnível máximo tolerado no footprint antes de desistir do local. |
| | `allow_on_water` | Permite fundação abaixo do nível do mar. |
| Terreno | `adaptation_mode` | `FLATTEN`, `PLATEAU`, `EMBED`, `CARVE`, `WATER_EDGE` ou `NONE`. |
| | `preferred_foundation_offset` | Sobe/desce a fundação em níveis (ex.: `-1` para um porão). |
| | `footprint_blocks_movement` | Marque se a própria cena controla a passagem. |

### Passo 3 — registrar

Duas opções:

* arraste o `.tres` para `structure_pool` de um ou mais biomas; **ou**
* arraste para `global_pool` em `res://data/world/structure_planner.tres` (aí
  `allowed_biomes` decide onde pode nascer).

Ajuste `attempts_per_region` no planejador para densificar ou rarear as
construções. Uma região é `generation_region_size_chunks²` chunks (padrão 4×4).

### O que acontece por baixo

1. `StructurePlanner` sorteia posições **por região**, não por chunk — por isso
   duas chunks vizinhas nunca brigam pelo mesmo lugar.
2. A fundação é a **mediana** das alturas do footprint (um pico isolado não
   distorce), mais `preferred_foundation_offset`.
3. `TerrainAdapter` achata o footprint e mistura a borda com `smoothstep`.
4. Só o chunk que contém a origem do footprint instancia a cena — uma casa pode
   atravessar 4 chunks sem duplicar.
5. Células do footprint ficam com `terrain_locked = true`: água, vegetação e
   relevo não mexem mais nelas.

### Usando os marcadores depois

```gdscript
var root := chunk_view.add_structure(placement) as StructureRoot
for marker in root.markers_of_type(StructureMarker.MarkerType.NPC_SPAWN):
    spawn_morador(marker.global_position)
```

---

## 4. Adicionar vegetação / objetos espalhados

1. Crie a cena (`Node2D` + `Sprite2D`, com `offset` deixando a base do objeto na
   origem — veja `arvore_ipe.tscn`: `centered = false`, `offset = (−64, −198)`).
2. `New Resource → DecorationDefinition`:
   * `density` — chance por célula. `0.05` já é uma mata razoável.
   * `minimum_spacing` — evita objetos colados.
   * `max_slope` — não nasce em encosta íngreme.
   * `allowed_terrains`, `min/max_world_height`, `allow_on_water`.
   * `max_biome_blend` — só nasce onde o bioma é dominante (rarefaz na fronteira).
   * `random_flip_h`, `min_scale`, `max_scale` — variedade visual.
   * `blocks_movement` — se marcado, a célula deixa de ser caminhável.
3. Arraste para o array `decorations` de um bioma.

---

## 5. Adicionar uma mecânica nova

### 5.1 Um passe novo na pipeline (rios, estradas, minério, ruínas…)

Este é o encaixe oficial. Exemplo — um passe que espalha veios de minério:

```gdscript
## res://world_generation/passes/ore_pass.gd
class_name OrePass
extends WorldGenerationPass

@export var sampler: WorldSampler
@export var ore_ground_id: StringName = &"pedra"
@export_range(0.0, 1.0, 0.001) var chance: float = 0.004


func rebind_shared(shared: Dictionary) -> void:
    sampler = WorldGenerationPass.shared_clone(shared, sampler)


func prepare(settings: WorldSettings, world_seed: int) -> void:
    if sampler != null:
        sampler.prepare(settings, world_seed)


func run(context: GenerationContext) -> void:
    var ore_seed := WorldRandom.sub_seed(context.world_seed, &"ore")
    for local in context.each_local():
        var cell := context.cell(local)
        if cell.terrain_locked or cell.height > 2:
            continue
        if WorldRandom.value_01(ore_seed, cell.world_xy) < chance:
            cell.ground_id = ore_ground_id
```

Depois:

1. `New Resource → OrePass`, salve em `data/world/passes/08_ore.tres`, ligue o
   `sampler`.
2. Abra `data/world/world_generator.tres` e arraste o novo `.tres` para a
   posição desejada do array `passes`.

**Ordem importa.** A pipeline atual é: clima → bioma → relevo → estruturas
(+adaptação) → classificação de relevo → água → decoração. Um rio deve entrar
depois do relevo e antes da água; uma estrada, depois das estruturas (para
ligar os `RoadMarker`).

Três regras inegociáveis dentro de um `run()`:

* **nunca** toque na `SceneTree` (roda em worker thread);
* **sempre** use coordenada mundial no ruído (`cell.world_xy`), nunca local —
  senão o padrão reinicia a cada chunk;
* **sempre** derive aleatoriedade de `WorldRandom` + semente do mundo, para o
  chunk ser reproduzível.

Cada passe tem `enabled` no Inspector: desligue para isolar um problema sem
remover nada.

### 5.2 Mudar as regras de movimento

Tudo mora em `world_generation/navigation/movement_rules.gd` e no
`MovementContext` (`data/world/player_movement_context.tres`).

| Campo | Efeito |
|---|---|
| `max_step_up` | Subida automática. `2` faria o jogador subir 2 níveis. |
| `max_step_down` | Descida automática. |
| `max_safe_fall` | Acima disso, o destino é bloqueado em vez de virar queda. |
| `can_swim` | Permite entrar em células líquidas (retorna `SWIM`). |
| `can_climb` | Reservado para escaladas. |

Crie contextos diferentes por tipo de entidade: `npc_idoso.tres` com
`max_step_up = 0`, `cavalo.tres` com `max_step_up = 2`, e assim por diante.
Player, NPC e A* leem o mesmo lugar — a regra nunca duplica.

### 5.3 Fazer um NPC andar

```gdscript
# NPC = Node2D com um WorldGridAgent filho
@onready var agent: WorldGridAgent = $WorldGridAgent

func ir_ate(destino: Vector2i) -> void:
    var nav := WorldNavigation.new(agent.world(), agent.movement_context)
    var caminho := nav.find_path(agent.cell(), destino)
    for ponto in caminho:
        var direcao := Vector2i(ponto.x, ponto.y) - agent.cell()
        if direcao == Vector2i.ZERO:
            continue
        agent.request_step(direcao)
        await agent.step_finished
```

Sinais úteis do agente: `step_started(de, para, transicao)`,
`step_finished(posicao)`, `height_changed(nivel)`, `step_blocked(direcao)`.

### 5.4 Reagir à queda, ao degrau, à água

```gdscript
agent.step_started.connect(func(de, para, transicao):
    match transicao:
        MovementRules.MovementTransition.FALL:
            player.damage((de.z - para.z) * 5)
        MovementRules.MovementTransition.STEP_UP:
            tocar_som_de_subida()
        MovementRules.MovementTransition.SWIM:
            entrar_no_modo_nado()
)
```

### 5.5 Alterar o mundo em tempo de jogo (cavar, construir, cortar árvore)

```gdscript
var patch := CellPatch.new()
patch.world_pos = Vector3i(x, y, 0)
patch.height_override = nova_altura
patch.ground_override = &"terra"
save_manager.patch_cell(patch)

# árvore cortada:
save_manager.remove_object(arvore.get_meta(&"object_id"))
```

O `WorldSaveManager` aplica os patches automaticamente sempre que o chunk é
regerado. O save guarda **semente + diferenças**, nunca o mundo inteiro.

### 5.6 Trocar a aparência do mundo inteiro

Edite `res://data/world/tiles/ground_catalog.tres`. Se você criar um TileSet
novo (outra escala, outro estilo), aponte `tile_set` e as `entries` para ele —
geração, IA, save e pathfinding não percebem a diferença.

---

## 6. Ligar os tiles de transição de bioma (tarefa pendente)

Você tem 4 conjuntos prontos em *Isometric Tiles/Tile Transicao de Bioma*
(`campo_para_musgo`, `campo_para_savana`, `campo_para_terra`,
`savana_para_terra`), cada um com 12 peças (`ponta_*`, `aresta_*`, `uniao_*`).

O dado necessário **já existe**: cada célula guarda `secondary_biome_id` e
`biome_blend`. O caminho:

1. Monte um segundo atlas com as 12 peças de cada par e registre-as no
   `TileSet`.
2. Crie um `BiomeTransitionCatalog` (`.tres`) mapeando
   `(bioma_a, bioma_b, máscara_de_vizinhos) → tile`.
3. No `ChunkView`, adicione uma camada de overlay por nível (uma segunda
   `height_layer.tscn` com `z_index` levemente maior) e, para cada célula com
   `biome_blend > limiar`, calcule a máscara dos 4 vizinhos e pinte a peça
   correspondente.

Nada disso exige mexer em geração, dados ou regras — é puramente renderização.

---

## 7. Checklist rápido de diagnóstico

| Sintoma | Causa provável |
|---|---|
| Mundo todo plano | `height_generator.contrast` muito baixo, ou o passe não recebeu `prepare` (o `sampler` está vazio no `.tres`?). |
| Um bioma nunca aparece | Faixas climáticas fora do alcance do ruído. Suba `climate_generator.contrast` ou alargue o intervalo. |
| Chão desalinhado da grade | `texture_origin` do tile no atlas ≠ `(0, −5)`, ou `tile_size` ≠ `(128, 64)`. |
| Fresta ou sobreposição entre níveis | `WorldSettings.height_pixels` ≠ altura da saia da sua arte (26 px). |
| Costura visível entre chunks | Algum passe usando coordenada local no ruído em vez de `cell.world_xy`. |
| Estrutura duplicada | Alguém instanciando fora do chunk que contém a origem do footprint. |
| Travamento ou mundo errado com threads | Recurso com estado compartilhado entre threads. Implemente `clone_for_thread()` nele. |
| Nada aparece na tela | `catalog` ou `chunk_view_scene` vazios no `ChunkManager`; ou o `focus` não foi ligado. |

---

## 8. Comandos úteis

```bash
# recriar todos os .tres do mundo do zero
godot --headless --path . --script res://tools/build_world_resources.gd

# testes de lógica (50 verificações)
godot --headless --path . --script res://tests/world_generation_test.gd

# testes de integração com SceneTree (21 verificações)
godot --headless --path . --script res://tests/player_grid_integration_test.gd
```

Rode os dois testes depois de qualquer mudança grande de configuração: eles
pegam mundo plano, bioma inalcançável, costura entre chunks, estrutura
duplicada e quebra de determinismo antes de você abrir o editor.
