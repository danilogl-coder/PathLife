## Teste de integração: mundo + jogador em grade dentro de uma SceneTree real.
##
## Uso:
##   godot --headless --path . --script res://tests/player_grid_integration_test.gd
extends SceneTree

var _passed := 0
var _failed := 0
var _world: ProceduralWorld
var _player: PlayerController
var _agent: WorldGridAgent


func _check(condition: bool, label: String, detail: String = "") -> void:
	if condition:
		_passed += 1
		print("  ok   %s" % label)
	else:
		_failed += 1
		printerr("  FALHA %s %s" % [label, detail])


func _init() -> void:
	root.set_process_mode(Node.PROCESS_MODE_ALWAYS)
	_build_scene.call_deferred()


func _build_scene() -> void:
	var container := Node2D.new()
	container.name = "Container"
	container.y_sort_enabled = true
	root.add_child(container)

	var anchor: Node2D = load("res://tests/player_grid_probe.tscn").instantiate()
	_player = anchor.get_node(^"Player")
	_agent = _player.get_node(^"WorldGridAgent")

	_world = load("res://scenes/world/procedural_world.tscn").instantiate()
	_world.focus = _player
	container.add_child(_world)
	container.add_child(anchor)

	await process_frame
	await process_frame
	await process_frame
	_run_checks()


func _run_checks() -> void:
	print("\n[Integração] mundo + jogador em grade")
	var data := _world.world_data()
	_check(data != null, "WorldData disponivel")
	_check(data.loaded_chunk_coords().size() > 0, "chunks carregados",
		"%d" % data.loaded_chunk_coords().size())
	_check(_agent.is_active(), "agente ativo")
	_check(_player.is_grid_driven(), "jogador dirigido pela grade")

	var iso := IsoCoordinateSystem.from_settings(_world.chunk_manager.settings)
	var expected := iso.world_to_local(_agent.world_position())
	_check(_player.global_position.is_equal_approx(expected),
		"posicao visual = projecao da logica",
		"%s vs %s" % [_player.global_position, expected])
	_check(_player.z_index == 0, "entidade fica em z_index 0 (ordenacao por Y-Sort)")
	var anchor_node := _player.get_parent() as Node2D
	var flat := iso.cell_to_local(_agent.cell()) + Vector2(0.0, iso.prop_sort_bias())
	_check(anchor_node.position.is_equal_approx(flat),
		"ancora carrega a posicao plana (chave de profundidade)",
		"%s vs %s" % [anchor_node.position, flat])

	var chunk_views := _world.chunk_manager.views()
	_check(chunk_views.size() > 0, "ChunkViews instanciadas", "%d" % chunk_views.size())
	var layers := 0
	var tiles := 0
	for view: ChunkView in chunk_views:
		layers += view.layer_levels().size()
		for level: int in view.layer_levels():
			tiles += view.layer_at(level).get_used_cells().size()
	_check(layers > 0, "camadas de altura criadas", "%d camadas" % layers)
	_check(tiles > 0, "tiles pintados", "%d tiles" % tiles)

	# Passo válido de verdade: procura uma direção liberada.
	var start := _agent.cell()
	var moved := false
	for direction: Vector2i in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
		var transition := _agent.request_step(direction)
		if transition != MovementRules.MovementTransition.BLOCKED:
			moved = true
			break
	_check(moved, "conseguiu dar um passo valido")
	if moved:
		var guard := 0
		while _agent.is_moving() and guard < 600:
			await process_frame
			guard += 1
		_check(not _agent.is_moving(), "passo terminou")
		_check(_agent.cell() != start, "celula logica mudou", "%s -> %s" % [start, _agent.cell()])
		var target := iso.world_to_local(_agent.world_position())
		_check(_player.global_position.is_equal_approx(target), "visual reancorado na celula nova",
			"%s vs %s" % [_player.global_position, target])

	# Passo impossível: nunca deve mover.
	var before := _agent.cell()
	var blocked_count := 0
	for i in 40:
		var far := Vector2i(0, 0)
		var transition := _agent.request_step(far)
		if transition == MovementRules.MovementTransition.BLOCKED:
			blocked_count += 1
	_check(blocked_count == 40, "direcao zero sempre bloqueada")
	_check(_agent.cell() == before, "celula nao muda quando bloqueado")

	# Descarregamento não deixa nós órfãos.
	var any_coord: Vector2i = _world.chunk_manager.world.loaded_chunk_coords()[0]
	_world.chunk_manager.unload_chunk(any_coord)
	_check(_world.chunk_manager.view_for(any_coord) == null, "view do chunk descarregada")
	_check(not _world.chunk_manager.world.has_chunk(any_coord), "dados do chunk removidos")

	await _test_streaming()

	print("\n==== %d passaram, %d falharam ====" % [_passed, _failed])
	quit(1 if _failed > 0 else 0)


## Anda bastante em linha reta e confere que o mundo continua carregando e
## descarregando sem sobrar (nem faltar) chunk.
func _test_streaming() -> void:
	print("\n[Streaming] atravessando chunks")
	var manager := _world.chunk_manager
	var settings := manager.settings
	var start_chunk := manager.current_center_chunk()
	var steps := settings.chunk_size * 2 + 4
	var teleports := 0
	for i in steps:
		_agent.teleport_to(_agent.cell() + Vector2i(1, 0))
		teleports += 1
		await process_frame
	# Deixa a fila assíncrona terminar.
	for i in 240:
		await process_frame
	var end_chunk := manager.current_center_chunk()
	_check(end_chunk != start_chunk, "o foco mudou de chunk", "%s -> %s" % [start_chunk, end_chunk])

	var limit := settings.render_distance + settings.unload_margin
	var too_far := 0
	for coord: Vector2i in manager.world.loaded_chunk_coords():
		if ChunkMath.chebyshev_distance(coord, end_chunk) > limit:
			too_far += 1
	_check(too_far == 0, "nenhum chunk distante ficou carregado", "%d sobraram" % too_far)

	var missing := 0
	for y in range(-settings.render_distance, settings.render_distance + 1):
		for x in range(-settings.render_distance, settings.render_distance + 1):
			if not manager.world.has_chunk(end_chunk + Vector2i(x, y)):
				missing += 1
	_check(missing == 0, "raio de renderizacao completo", "%d faltando" % missing)
	_check(manager.views().size() == manager.world.loaded_chunk_coords().size(),
		"views e dados em sincronia",
		"%d views / %d chunks" % [manager.views().size(), manager.world.loaded_chunk_coords().size()])
