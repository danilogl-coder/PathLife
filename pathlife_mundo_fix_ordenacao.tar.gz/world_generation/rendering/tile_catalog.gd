## Catálogo que traduz ids lógicos em coordenadas do TileSet.
##
## É aqui — e só aqui — que "dado" vira "tile". Trocar a arte do mundo inteiro
## significa trocar este `.tres`, sem tocar em geração, IA ou save.
##
## [b]Altura e ordenação[/b]: cada tile de chão tem um [i]alternative tile[/i]
## por nível de altura. O deslocamento vertical do nível vive no
## `texture_origin` da alternativa (e não na posição do nó da camada), e o
## `y_sort_origin` guarda o nível. Isso faz o mundo inteiro ser ordenado pela
## profundidade real — `x + y` primeiro, altura como desempate — em vez de por
## `z_index` de altura, que fazia terreno alto ATRÁS do jogador cobri-lo.
class_name TileCatalog
extends Resource

@export var tile_set: TileSet
@export var entries: Array[GroundTileEntry] = []
## Usado quando um id não está catalogado (evita mundo invisível por engano).
@export var fallback_ground_id: StringName = &"terra"

@export_group("Alturas suportadas")
## Menor nível com alternativa gerada no TileSet.
@export var level_min: int = -16
## Maior nível com alternativa gerada no TileSet.
@export var level_max: int = 24

var _lookup: Dictionary = {}


func _ensure_lookup() -> void:
	if not _lookup.is_empty():
		return
	for entry in entries:
		if entry != null:
			_lookup[entry.ground_id] = entry


func find(ground_id: StringName) -> GroundTileEntry:
	_ensure_lookup()
	if _lookup.has(ground_id):
		return _lookup[ground_id]
	if _lookup.has(fallback_ground_id):
		return _lookup[fallback_ground_id]
	return null


func has(ground_id: StringName) -> bool:
	_ensure_lookup()
	return _lookup.has(ground_id)


## Id da alternativa que desenha o tile no nível informado.
func alternative_for(level: int) -> int:
	return 1 + clampi(level, level_min, level_max) - level_min


func supports_level(level: int) -> bool:
	return level >= level_min and level <= level_max


func rebuild() -> void:
	_lookup.clear()
	_ensure_lookup()
