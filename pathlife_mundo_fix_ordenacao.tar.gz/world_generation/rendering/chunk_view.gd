## Representação VISUAL de um chunk. Não guarda regra de jogo.
##
## Um [TileMapLayer] por nível de altura, criado só para os níveis realmente
## usados. Cada camada é instanciada a partir de `height_layer.tscn`, então
## continua sendo um nó configurável no editor.
##
## [b]Ordenação de profundidade[/b]: TODAS as camadas ficam em `position = 0` e
## `z_index = 0`. O deslocamento vertical do nível vem do `texture_origin` da
## alternativa de tile (ver [TileCatalog]), e o nível vai para o
## `y_sort_origin`. Resultado: o mundo inteiro — terreno, vegetação, estruturas
## e entidades — é ordenado num único Y-Sort por `x + y`, que é a profundidade
## real da projeção isométrica. Usar `z_index` por altura fazia qualquer terreno
## mais alto (mesmo ATRÁS do jogador) ser desenhado por cima dele.
class_name ChunkView
extends Node2D

@export var height_layer_scene: PackedScene
## Nó vazio usado como âncora de ordenação de árvores e estruturas.
@export var prop_anchor_scene: PackedScene
@export var catalog: TileCatalog
@export var settings: WorldSettings

@onready var height_layers: Node2D = %HeightLayers
@onready var structures_root: Node2D = %Structures
@onready var decorations_root: Node2D = %Decorations

var chunk_coord: Vector2i = Vector2i.ZERO

var _layers: Dictionary = {}
var _base_tints: Dictionary = {}
var _visibility_tints: Dictionary = {}
var _iso: IsoCoordinateSystem
var _reference_level: int = 0


func build(chunk: ChunkData, p_settings: WorldSettings, p_catalog: TileCatalog) -> void:
	settings = p_settings
	catalog = p_catalog
	chunk_coord = chunk.coord
	_iso = IsoCoordinateSystem.from_settings(settings)

	_clear()
	_paint_ground(chunk)


func _clear() -> void:
	for layer: TileMapLayer in _layers.values():
		layer.queue_free()
	_layers.clear()
	_base_tints.clear()
	_visibility_tints.clear()
	for child in structures_root.get_children():
		child.queue_free()
	for child in decorations_root.get_children():
		child.queue_free()


func _paint_ground(chunk: ChunkData) -> void:
	var size := chunk.size
	for y in size:
		for x in size:
			var cell := chunk.get_cell(Vector2i(x, y))
			if cell == null:
				continue
			var cell_coord := Vector2i(cell.world_xy.x, cell.world_xy.y)

			# 1) bloco de topo
			_set_tile(cell.height, cell_coord, cell.ground_id)

			# 2) coluna de parede até o vizinho da frente mais baixo
			var lowest := _lowest_front_neighbor(chunk, cell)
			var depth := 0
			var level := cell.height - 1
			while level > lowest and depth < settings.max_wall_depth:
				_set_tile(level, cell_coord, cell.wall_id)
				level -= 1
				depth += 1

			# 3) superfície de água
			if cell.is_liquid():
				_set_tile(settings.sea_level, cell_coord, settings.water_ground_id)


## Vizinhos "da frente" na projeção isométrica: (x+1, y) e (x, y+1).
func _lowest_front_neighbor(chunk: ChunkData, cell: WorldCell) -> int:
	var lowest := cell.height
	for offset: Vector2i in [Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)]:
		var neighbor := chunk.get_cell_world(cell.world_xy + offset)
		if neighbor == null:
			# Fora do chunk: assume um degrau, evitando buraco visual na borda.
			lowest = mini(lowest, cell.height - 1)
		else:
			lowest = mini(lowest, neighbor.height)
	return lowest


func _set_tile(level: int, cell_coord: Vector2i, ground_id: StringName) -> void:
	if catalog == null:
		return
	var entry := catalog.find(ground_id)
	if entry == null:
		return
	_layer_for(level).set_cell(
		cell_coord, entry.source_id, entry.atlas_coords, catalog.alternative_for(level)
	)


func _layer_for(level: int) -> TileMapLayer:
	if _layers.has(level):
		return _layers[level]
	var layer: TileMapLayer = height_layer_scene.instantiate()
	layer.name = "Height_%d" % level
	layer.tile_set = catalog.tile_set
	# A camada NÃO é deslocada: o deslocamento vertical do nível está no
	# texture_origin da alternativa do tile. Mover o nó aqui quebraria a
	# ordenação por profundidade.
	layer.position = Vector2.ZERO
	layer.z_index = 0
	height_layers.add_child(layer)
	_layers[level] = layer
	_apply_tint(level)
	return layer


func layer_levels() -> Array:
	return _layers.keys()


func layer_at(level: int) -> TileMapLayer:
	return _layers.get(level, null)


## Instancia uma decoração já decidida pelos dados.
func add_decoration(placement: DecorationPlacement) -> Node2D:
	if placement.definition == null or placement.definition.scene == null:
		return null
	var instance: Node2D = placement.definition.scene.instantiate()
	instance.scale = Vector2(
		-placement.scale_factor if placement.flip_h else placement.scale_factor,
		placement.scale_factor
	)
	instance.set_meta(&"object_id", placement.object_id)
	instance.set_meta(&"world_position", placement.world_pos)
	_anchor_prop(instance, placement.world_pos, decorations_root)
	return instance


## Instancia uma estrutura já planejada.
func add_structure(placement: StructurePlacement) -> Node2D:
	if placement.definition == null or placement.definition.scene == null:
		return null
	var instance: Node2D = placement.definition.scene.instantiate()
	var root := instance as StructureRoot
	if root != null:
		root.setup(placement)
	_anchor_prop(
		instance,
		Vector3i(placement.origin_xy.x, placement.origin_xy.y, placement.foundation_height),
		structures_root
	)
	return instance


## Pendura um objeto do mundo em uma âncora posicionada no plano da grade.
##
## A âncora carrega a posição PLANA da célula (é ela que entra no Y-Sort) e o
## objeto recebe só o deslocamento vertical da altura. Sem isso, um objeto em
## cima de um morro seria ordenado como se estivesse mais ao fundo.
func _anchor_prop(prop: Node2D, world_pos: Vector3i, parent: Node2D) -> void:
	var cell := Vector2i(world_pos.x, world_pos.y)
	var anchor: Node2D = (
		prop_anchor_scene.instantiate() if prop_anchor_scene != null else Node2D.new()
	)
	anchor.name = "Anchor_%d_%d" % [cell.x, cell.y]
	anchor.y_sort_enabled = false
	anchor.position = _iso.cell_to_local(cell) + Vector2(0.0, _iso.prop_sort_bias())
	parent.add_child(anchor)
	anchor.add_child(prop)
	prop.position = Vector2(0.0, -float(world_pos.z * settings.height_pixels) - _iso.prop_sort_bias())
	prop.z_index = 0


## Usado pelo [HeightVisibilityManager]. Não altera dados, só aparência.
##
## A cor recebida é MULTIPLICADA pelo sombreamento de altura da camada, para os
## dois sistemas conviverem sem um apagar o outro.
func apply_level_modulation(level: int, color: Color, layer_visible: bool) -> void:
	var layer: TileMapLayer = _layers.get(level, null)
	if layer == null:
		return
	layer.visible = layer_visible
	_visibility_tints[level] = color
	_apply_tint(level)


## Nível de referência do sombreamento (normalmente onde o jogador está).
func set_reference_level(level: int) -> void:
	if _reference_level == level:
		return
	_reference_level = level
	for existing_level: int in _layers:
		_apply_tint(existing_level)


func reference_level() -> int:
	return _reference_level


func _apply_tint(level: int) -> void:
	var layer: TileMapLayer = _layers.get(level, null)
	if layer == null or settings == null:
		return
	var base := settings.tint_for_level(level, _reference_level)
	_base_tints[level] = base
	var overlay: Color = _visibility_tints.get(level, Color.WHITE)
	layer.modulate = Color(
		base.r * overlay.r, base.g * overlay.g, base.b * overlay.b, base.a * overlay.a
	)
