## Configuração global do mundo procedural.
##
## É um [Resource]: crie um `.tres` em `res://data/world/` e ajuste tudo pelo
## Inspector. Nenhum sistema deve ler números mágicos direto do código.
class_name WorldSettings
extends Resource

@export_category("Semente")
## Semente mestre do mundo. 0 = sorteia uma semente ao iniciar.
@export var world_seed: int = 20260819

@export_category("Chunks")
@export_range(4, 64, 1) var chunk_size: int = 16
## Raio (em chunks) mantido carregado ao redor do jogador.
@export_range(0, 8, 1) var render_distance: int = 2
## Quantos chunks além do raio ficam vivos antes de descarregar (histerese).
@export_range(0, 4, 1) var unload_margin: int = 1
## Tamanho da região macro (em chunks) usada para planejar estruturas grandes.
@export_range(1, 32, 1) var generation_region_size_chunks: int = 4

@export_category("Projeção isométrica")
## Tamanho do losango da face superior do tile (deve bater com o TileSet).
@export var tile_size: Vector2i = Vector2i(128, 64)
## Altura em pixels de um nível de terreno (altura da lateral do bloco).
@export_range(1, 128, 1) var height_pixels: int = 26

@export_category("Limites de altura")
@export_range(-64, 0, 1) var min_height: int = -8
@export_range(0, 64, 1) var max_height: int = 14
## Altura da lâmina d'água. Células abaixo disso viram líquido.
@export_range(-64, 64, 1) var sea_level: int = 0

@export_category("Geração assíncrona")
## Quantos chunks podem ser gerados em paralelo. Também define quantas cópias
## dos recursos de geração são criadas (uma por thread, para evitar disputa).
@export_range(1, 16, 1) var max_parallel_generations: int = 4
## Quantos chunks no máximo são integrados na SceneTree por frame.
@export_range(1, 16, 1) var max_chunk_integrations_per_frame: int = 1
## Se falso, gera tudo na main thread (útil para depurar).
@export var use_worker_threads: bool = true

@export_category("Renderização")
## Profundidade máxima de parede desenhada abaixo de um bloco.
@export_range(1, 32, 1) var max_wall_depth: int = 6
## Id do tile desenhado na superfície da água (precisa existir no TileCatalog).
@export var water_ground_id: StringName = &"agua"

@export_group("Leitura de altura")
## Escurece os níveis mais baixos. É o principal indicativo visual de "este
## bloco está mais fundo" — sem isso, dois patamares vizinhos ficam idênticos.
@export var height_shading_enabled: bool = true
## Quanto de brilho cada nível ganha (ou perde) em relação ao nível de
## referência. O passo é POR NÍVEL, não pela faixa toda: é isso que faz dois
## patamares vizinhos serem distinguíveis.
@export_range(0.0, 0.35, 0.005) var height_shading_step: float = 0.115
## Multiplicador aplicado ao nível de referência. Deixar abaixo de 1 dá espaço
## para os níveis ACIMA clarearem sem estourar a cor.
@export_range(0.3, 1.0, 0.01) var height_shading_base: float = 0.88
## Nível neutro (multiplicador 1.0) usado enquanto ninguém informa outro.
## Em jogo, o [HeightVisibilityManager] passa o nível do jogador.
@export var height_shading_reference: int = 0
## Limites do multiplicador, para o mundo não saturar em preto nem estourar.
@export_range(0.2, 1.0, 0.01) var height_shading_min: float = 0.46
@export_range(0.5, 2.0, 0.01) var height_shading_max: float = 1.06
## Quanto os níveis baixos puxam para o azul (sombra fria). 0 = cinza puro.
@export_range(0.0, 1.0, 0.01) var height_shading_coolness: float = 0.45


## Cor de multiplicação da camada de um nível.
##
## O sombreamento é RELATIVO a um nível de referência (normalmente o nível em
## que o jogador está). Um degradê absoluto sobre 20+ níveis daria menos de 3%
## de diferença entre patamares vizinhos — invisível. Relativo, cada nível ganha
## um passo cheio de contraste e dá para ler de bate-pronto o que está acima e
## o que está abaixo.
func tint_for_level(level: int, reference_level: int = 2147483647) -> Color:
	if not height_shading_enabled:
		return Color.WHITE
	var reference := height_shading_reference
	if reference_level != 2147483647:
		reference = reference_level
	var factor := clampf(
		height_shading_base + float(level - reference) * height_shading_step,
		height_shading_min,
		height_shading_max
	)
	# Quanto mais escuro, mais frio: sombra puxando para o azul lê melhor do
	# que um cinza chapado.
	var cool := maxf(height_shading_base - factor, 0.0) * height_shading_coolness
	return Color(
		factor * (1.0 - cool * 0.45),
		factor * (1.0 - cool * 0.18),
		factor,
		1.0
	)


## Semente efetiva. Se [member world_seed] for 0, sorteia uma nova.
func resolved_seed() -> int:
	if world_seed != 0:
		return world_seed
	return int(Time.get_unix_time_from_system() * 1000.0) & 0x7FFFFFFF
