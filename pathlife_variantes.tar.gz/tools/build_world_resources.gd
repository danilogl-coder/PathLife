## Ferramenta: (re)cria todos os `.tres` do mundo procedural.
##
## Uso:
##   godot --headless --path . --script res://tools/build_world_resources.gd
##
## Os arquivos gerados são recursos normais: depois de criados, edite tudo pelo
## Inspector. Este script serve para recriar a base do zero ou versionar
## mudanças grandes de configuração.
extends SceneTree

const OUT := "res://data/world/"

var _saved: Array[String] = []


func _init() -> void:
	_ensure_dirs()
	var noises := _build_noises()
	var climate: ClimateGenerator = _save(_build_climate(noises), OUT + "climate_generator.tres")
	var height: HeightGenerator = _save(_build_height(noises), OUT + "height_generator.tres")
	var terrains := _build_terrains()
	var terrain_resolver: TerrainResolver = _save(_build_terrain_resolver(terrains), OUT + "terrain_resolver.tres")
	var decorations := _build_decorations()
	var structures := _build_structures()
	var biomes := _build_biomes(decorations, structures)
	var biome_resolver: BiomeResolver = _save(_build_biome_resolver(biomes), OUT + "biome_resolver.tres")

	var sampler := WorldSampler.new()
	sampler.climate = climate
	sampler.biome_resolver = biome_resolver
	sampler.height_generator = height
	sampler.terrain_resolver = terrain_resolver
	sampler.variation_noise = noises["ground_variation"]
	sampler.resource_name = "WorldSampler"
	_save(sampler, OUT + "world_sampler.tres")

	var settings := WorldSettings.new()
	# Sem arte de água fornecida: a lâmina d'água fica abaixo do piso do mundo,
	# então nenhuma célula é submersa. Basta subir isto (e catalogar um tile de
	# água) para ligar oceanos e lagos.
	settings.sea_level = settings.min_height
	settings.water_ground_id = &"campo_terra"
	settings.resource_name = "WorldSettings"
	_save(settings, OUT + "world_settings.tres")

	var planner := StructurePlanner.new()
	planner.sampler = sampler
	planner.resource_name = "StructurePlanner"
	_save(planner, OUT + "structure_planner.tres")

	var generator := _build_generator(sampler, planner)
	_save(generator, OUT + "world_generator.tres")

	var tile_set := _build_tileset()
	_save(tile_set, OUT + "tiles/ground_tileset.tres")
	_save(_build_catalog(tile_set), OUT + "tiles/ground_catalog.tres")

	var movement := MovementContext.new()
	movement.resource_name = "PlayerMovementContext"
	_save(movement, OUT + "player_movement_context.tres")

	print("\n--- %d recursos gravados ---" % _saved.size())
	for path in _saved:
		print("  ", path)
	quit(0)


# ------------------------------------------------------------------ helpers
func _ensure_dirs() -> void:
	for sub in [
		"", "noise/", "biomes/", "variants/", "terrains/", "decorations/", "structures/",
		"passes/", "tiles/",
	]:
		DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUT + sub))
		DirAccess.make_dir_recursive_absolute(OUT + sub)


func _save(resource: Resource, path: String) -> Resource:
	var error := ResourceSaver.save(resource, path)
	if error != OK:
		push_error("Falha ao gravar %s (erro %d)" % [path, error])
	else:
		resource.take_over_path(path)
		_saved.append(path)
	return resource


func _noise(
	name: String,
	frequency: float,
	noise_type: int,
	octaves: int = 4,
	lacunarity: float = 2.0,
	gain: float = 0.5
) -> FastNoiseLite:
	var noise := FastNoiseLite.new()
	noise.noise_type = noise_type
	noise.frequency = frequency
	noise.fractal_octaves = octaves
	noise.fractal_lacunarity = lacunarity
	noise.fractal_gain = gain
	noise.resource_name = name
	var saved: FastNoiseLite = _save(noise, OUT + "noise/%s.tres" % name)
	return saved


func _build_noises() -> Dictionary:
	return {
		"temperature": _noise("temperature", 0.9, FastNoiseLite.TYPE_SIMPLEX_SMOOTH, 3),
		"humidity": _noise("humidity", 1.1, FastNoiseLite.TYPE_SIMPLEX_SMOOTH, 3),
		"continentalness": _noise("continentalness", 0.8, FastNoiseLite.TYPE_SIMPLEX_SMOOTH, 3),
		"weirdness": _noise("weirdness", 1.4, FastNoiseLite.TYPE_SIMPLEX_SMOOTH, 2),
		"elevation": _noise("elevation", 1.0, FastNoiseLite.TYPE_SIMPLEX_SMOOTH, 4),
		"mountain": _noise("mountain", 1.0, FastNoiseLite.TYPE_SIMPLEX, 4, 2.1, 0.55),
		"roughness": _noise("roughness", 1.0, FastNoiseLite.TYPE_SIMPLEX_SMOOTH, 3),
		"detail": _noise("detail", 1.0, FastNoiseLite.TYPE_SIMPLEX_SMOOTH, 2),
		"ground_variation": _noise("ground_variation", 1.0, FastNoiseLite.TYPE_SIMPLEX_SMOOTH, 3),
	}


func _build_climate(noises: Dictionary) -> ClimateGenerator:
	var climate := ClimateGenerator.new()
	climate.temperature_noise = noises["temperature"]
	climate.humidity_noise = noises["humidity"]
	climate.continentalness_noise = noises["continentalness"]
	climate.weirdness_noise = noises["weirdness"]
	climate.biome_scale = 420.0
	climate.continent_scale = 1400.0
	climate.resource_name = "ClimateGenerator"
	return climate


func _build_height(noises: Dictionary) -> HeightGenerator:
	var height := HeightGenerator.new()
	height.continentalness_noise = noises["continentalness"]
	height.elevation_noise = noises["elevation"]
	height.mountain_noise = noises["mountain"]
	height.roughness_noise = noises["roughness"]
	height.detail_noise = noises["detail"]
	height.resource_name = "HeightGenerator"
	return height


# ------------------------------------------------------------------ terrenos
func _terrain(
	id: StringName,
	display: String,
	roughness: Vector2,
	slope: Vector2,
	weight: float,
	override_ground: StringName = &"",
	walkable: bool = true,
	allows_structures: bool = true,
	expose_biome_wall: bool = false
) -> TerrainDefinition:
	var terrain := TerrainDefinition.new()
	terrain.id = id
	terrain.display_name = display
	terrain.min_roughness = roughness.x
	terrain.max_roughness = roughness.y
	terrain.min_slope = slope.x
	terrain.max_slope = slope.y
	terrain.weight = weight
	terrain.ground_override_id = override_ground
	terrain.walkable = walkable
	terrain.allows_structures = allows_structures
	terrain.expose_biome_wall = expose_biome_wall
	terrain.resource_name = String(id)
	var saved: TerrainDefinition = _save(terrain, OUT + "terrains/%s.tres" % id)
	return saved


func _build_terrains() -> Array[TerrainDefinition]:
	var result: Array[TerrainDefinition] = []
	result.append(_terrain(&"plano", "Plano", Vector2(0.0, 0.60), Vector2(0.0, 1.0), 1.0))
	result.append(_terrain(&"colina", "Colina", Vector2(0.35, 0.85), Vector2(1.0, 2.5), 1.0))
	# `expose_biome_wall` faz o relevo íngreme mostrar a terra do próprio bioma
	# em vez da grama. Vem DESLIGADO para o mundo continuar coberto de grama;
	# ligue no `.tres` do terreno se quiser encostas de solo exposto.
	result.append(_terrain(
		&"montanha", "Montanha", Vector2(0.60, 1.0), Vector2(2.0, 16.0), 1.0, &"", true, false, false
	))
	result.append(_terrain(
		&"penhasco", "Penhasco", Vector2(0.0, 1.0), Vector2(4.0, 16.0), 1.2, &"", true, false, false
	))
	return result


func _build_terrain_resolver(terrains: Array[TerrainDefinition]) -> TerrainResolver:
	var resolver := TerrainResolver.new()
	resolver.terrains = terrains
	resolver.fallback_terrain = terrains[0]
	resolver.resource_name = "TerrainResolver"
	return resolver


# --------------------------------------------------------------- decorações
func _decoration(
	id: StringName,
	scene_path: String,
	density: float,
	spacing: int,
	max_slope: float = 1.0,
	weight: float = 1.0
) -> DecorationDefinition:
	var decoration := DecorationDefinition.new()
	decoration.id = id
	decoration.scene = load(scene_path)
	decoration.density = density
	decoration.minimum_spacing = spacing
	decoration.max_slope = max_slope
	decoration.weight = weight
	decoration.resource_name = String(id)
	var saved: DecorationDefinition = _save(decoration, OUT + "decorations/%s.tres" % id)
	return saved


func _build_decorations() -> Dictionary:
	const BASE := "res://presentation/world/vegetation/"
	return {
		"alamo": _decoration(&"alamo", BASE + "arvore_alamo.tscn", 0.05, 3),
		"baoba": _decoration(&"baoba", BASE + "arvore_baoba.tscn", 0.025, 6),
		"ipe": _decoration(&"ipe", BASE + "arvore_ipe.tscn", 0.05, 3),
		"palmeira": _decoration(&"palmeira", BASE + "arvore_palmeira.tscn", 0.03, 5),
		"salgueiro": _decoration(&"salgueiro", BASE + "arvore_salgueiro.tscn", 0.05, 3),
		"sequoia": _decoration(&"sequoia", BASE + "arvore_sequoia.tscn", 0.09, 2),
	}


# --------------------------------------------------------------- estruturas
func _build_structures() -> Dictionary:
	var deck := StructureDefinition.new()
	deck.id = &"deck_madeira"
	deck.display_name = "Deck de madeira"
	deck.scene = load("res://presentation/world/structures/deck_madeira.tscn")
	deck.footprint = Vector2i(4, 4)
	deck.adaptation_margin = 5
	deck.spawn_weight = 1.0
	deck.spawn_chance = 0.6
	deck.minimum_spacing = 40
	deck.max_slope = 6.0
	deck.adaptation_mode = StructureDefinition.TerrainAdaptationMode.FLATTEN
	deck.allowed_biomes = [&"campo", &"campo_claro", &"campo_florido", &"floresta"]
	deck.resource_name = "deck_madeira"
	_save(deck, OUT + "structures/deck_madeira.tres")
	return {"deck": deck}


# ------------------------------------------------------------------- biomas
func _biome(
	id: StringName,
	display: String,
	temperature: Vector2,
	humidity: Vector2,
	continentalness: Vector2,
	ground: StringName,
	wall: StringName,
	height_bias: float,
	amplitude: float,
	decorations: Array[DecorationDefinition],
	structures: Array[StructureDefinition] = [],
	weight: float = 1.0,
	variants: Array[GroundVariant] = []
) -> BiomeDefinition:
	var biome := BiomeDefinition.new()
	biome.id = id
	biome.display_name = display
	biome.temperature_min = temperature.x
	biome.temperature_max = temperature.y
	biome.humidity_min = humidity.x
	biome.humidity_max = humidity.y
	biome.continentalness_min = continentalness.x
	biome.continentalness_max = continentalness.y
	biome.ground_id = ground
	biome.wall_id = wall
	biome.underwater_ground_id = wall
	biome.height_bias = height_bias
	biome.height_amplitude = amplitude
	biome.weight = weight
	biome.ground_variants = variants
	biome.decorations = decorations
	biome.structure_pool = structures
	biome.resource_name = String(id)
	var saved: BiomeDefinition = _save(biome, OUT + "biomes/%s.tres" % id)
	return saved


## Variantes de grama de um bioma, da mais densa para a mais rala.
##
## A ORDEM importa: o sorteio percorre o array conforme o ruído sobe, então
## variantes vizinhas no array viram manchas vizinhas no mapa.
func _variants(entries: Array) -> Array[GroundVariant]:
	var result: Array[GroundVariant] = []
	for entry: Array in entries:
		var variant := GroundVariant.new()
		variant.ground_id = entry[0]
		variant.weight = entry[1]
		variant.resource_name = String(entry[0])
		_save(variant, OUT + "variants/%s.tres" % entry[0])
		result.append(variant)
	return result


## Um bioma por PASTA de bioma da arte original — cada um com as suas variantes.
func _build_biomes(d: Dictionary, s: Dictionary) -> Array[BiomeDefinition]:
	var deck: Array[StructureDefinition] = [s["deck"]]
	var result: Array[BiomeDefinition] = []

	result.append(_biome(&"campo_claro", "Campo claro", Vector2(0.0, 0.36), Vector2(0.0, 1.0),
		Vector2(0.0, 1.0), &"claro", &"campo_claro_terra", 0.8, 1.15,
		[d["alamo"]] as Array[DecorationDefinition], deck, 1.0,
		_variants([[&"claro_denso", 0.8], [&"claro", 1.5]])))

	result.append(_biome(&"campo", "Campo", Vector2(0.36, 0.68), Vector2(0.0, 0.55),
		Vector2(0.0, 1.0), &"campo_baixo", &"campo_terra", 0.0, 1.0,
		[d["ipe"], d["alamo"]] as Array[DecorationDefinition], deck, 1.15,
		_variants([
			[&"campo_mato_denso", 0.6], [&"campo_alto", 0.9], [&"campo_baixo", 1.6],
			[&"campo_quase_ralo", 0.7], [&"campo_ralo", 0.45],
		])))

	result.append(_biome(&"floresta", "Floresta", Vector2(0.30, 0.68), Vector2(0.55, 1.0),
		Vector2(0.0, 1.0), &"musgo", &"floresta_terra", 0.4, 1.1,
		[d["sequoia"], d["salgueiro"], d["ipe"]] as Array[DecorationDefinition], deck, 1.05,
		_variants([[&"floresta", 0.9], [&"musgo", 1.5], [&"floresta_rasteira", 0.7]])))

	result.append(_biome(&"campo_florido", "Campo florido", Vector2(0.68, 1.0), Vector2(0.48, 1.0),
		Vector2(0.0, 1.0), &"florida_baixa", &"campo_florido_terra", 0.0, 0.95,
		[d["ipe"]] as Array[DecorationDefinition], deck, 1.0,
		_variants([[&"florida", 0.8], [&"florida_baixa", 1.5], [&"florida_rasteira", 0.7]])))

	result.append(_biome(&"savana", "Savana", Vector2(0.68, 1.0), Vector2(0.0, 0.48),
		Vector2(0.0, 1.0), &"savana_baixa", &"savana_terra", 0.0, 0.85,
		[d["baoba"], d["palmeira"]] as Array[DecorationDefinition], [], 1.05,
		_variants([[&"savana", 0.9], [&"savana_baixa", 1.5], [&"savana_rasteira", 0.7]])))
	return result


func _build_biome_resolver(biomes: Array[BiomeDefinition]) -> BiomeResolver:
	var resolver := BiomeResolver.new()
	resolver.biomes = biomes
	for biome in biomes:
		if biome.id == &"campo":
			resolver.fallback_biome = biome
	resolver.resource_name = "BiomeResolver"
	return resolver


# ---------------------------------------------------------------- pipeline
func _build_generator(sampler: WorldSampler, planner: StructurePlanner) -> WorldGenerator:
	var passes: Array[WorldGenerationPass] = []

	var climate_pass := ClimatePass.new()
	climate_pass.pass_name = "1 - Clima macro"
	climate_pass.sampler = sampler
	_save(climate_pass, OUT + "passes/01_climate.tres")
	passes.append(climate_pass)

	var biome_pass := BiomePass.new()
	biome_pass.pass_name = "2 - Biomas"
	biome_pass.sampler = sampler
	_save(biome_pass, OUT + "passes/02_biome.tres")
	passes.append(biome_pass)

	var height_pass := HeightPass.new()
	height_pass.pass_name = "3 - Relevo base"
	height_pass.sampler = sampler
	_save(height_pass, OUT + "passes/03_height.tres")
	passes.append(height_pass)

	var structure_pass := StructurePass.new()
	structure_pass.pass_name = "4 - Estruturas + adaptacao do terreno"
	structure_pass.planner = planner
	_save(structure_pass, OUT + "passes/04_structures.tres")
	passes.append(structure_pass)

	var terrain_pass := TerrainPass.new()
	terrain_pass.pass_name = "5 - Classificacao de relevo"
	terrain_pass.sampler = sampler
	_save(terrain_pass, OUT + "passes/05_terrain.tres")
	passes.append(terrain_pass)

	var water_pass := WaterPass.new()
	water_pass.pass_name = "6 - Agua (desligado: falta arte de agua)"
	water_pass.sampler = sampler
	water_pass.water_ground_id = &"campo_terra"
	water_pass.enabled = false
	_save(water_pass, OUT + "passes/06_water.tres")
	passes.append(water_pass)

	var decoration_pass := DecorationPass.new()
	decoration_pass.pass_name = "7 - Decoracao"
	decoration_pass.sampler = sampler
	_save(decoration_pass, OUT + "passes/07_decoration.tres")
	passes.append(decoration_pass)

	var generator := WorldGenerator.new()
	generator.passes = passes
	generator.resource_name = "WorldGenerator"
	return generator


# ------------------------------------------------------------------- tiles
## Linhas do atlas, na ordem. As 6 primeiras são a arte fornecida (animada, 3
## frames); as 6 seguintes são os blocos de terra derivados de cada uma delas
## (estáticos), usados nas paredes e colunas abaixo da grama.
const GROUND_ROWS: Array[StringName] = [
	# 16 variantes de grama fornecidas (animadas, 3 frames cada)
	&"campo_alto", &"campo_mato_denso", &"campo_quase_ralo", &"campo_ralo", &"campo_baixo",
	&"claro_denso", &"claro",
	&"florida", &"florida_rasteira", &"florida_baixa",
	&"floresta", &"floresta_rasteira", &"musgo",
	&"savana", &"savana_rasteira", &"savana_baixa",
	# 5 blocos de terra derivados (estáticos), um por bioma
	&"campo_terra", &"campo_claro_terra", &"campo_florido_terra",
	&"floresta_terra", &"savana_terra",
]
## Quantas linhas do atlas são animadas (as fornecidas). O resto é estático.
const ANIMATED_ROWS := 16


## Deslocamento do losango dentro da região 128x106 do atlas.
const TILE_ART_OFFSET := -5
## Altura em pixels de um nível (precisa bater com WorldSettings.height_pixels).
const HEIGHT_PIXELS := 26
## Faixa de níveis para a qual são geradas alternativas de tile.
const LEVEL_MIN := -16
const LEVEL_MAX := 24


func _build_tileset() -> TileSet:
	var tile_set := TileSet.new()
	tile_set.tile_shape = TileSet.TILE_SHAPE_ISOMETRIC
	tile_set.tile_layout = TileSet.TILE_LAYOUT_DIAMOND_DOWN
	tile_set.tile_offset_axis = TileSet.TILE_OFFSET_AXIS_HORIZONTAL
	tile_set.tile_size = Vector2i(128, 64)
	tile_set.resource_name = "GroundTileSet"

	var source := TileSetAtlasSource.new()
	source.texture = load("res://assets/world/tiles/ground_atlas.png")
	source.texture_region_size = Vector2i(128, 106)
	source.resource_name = "GroundAtlas"

	for row in GROUND_ROWS.size():
		var coords := Vector2i(0, row)
		source.create_tile(coords)
		if row < ANIMATED_ROWS:
			source.set_tile_animation_columns(coords, 3)
			source.set_tile_animation_frames_count(coords, 3)
			source.set_tile_animation_speed(coords, 1.4)
			for frame in 3:
				source.set_tile_animation_frame_duration(coords, frame, 1.0)
		# Alternativa 0 = nível 0 (base).
		var base := source.get_tile_data(coords, 0)
		base.texture_origin = Vector2i(0, TILE_ART_OFFSET)
		base.y_sort_origin = 0

		# Uma alternativa por nível de altura. O deslocamento vertical vive no
		# texture_origin (visual) e o nível no y_sort_origin (ordenação dentro
		# da mesma célula). Assim a camada do nó pode ficar em y = 0 e o mundo
		# inteiro é ordenado por profundidade real.
		for level in range(LEVEL_MIN, LEVEL_MAX + 1):
			var alternative := source.create_alternative_tile(coords, 1 + level - LEVEL_MIN)
			var data := source.get_tile_data(coords, alternative)
			# texture_origin é SUBTRAÍDO da posição de desenho, então para subir
			# o bloco em `level * HEIGHT_PIXELS` o valor precisa ser POSITIVO.
			data.texture_origin = Vector2i(0, TILE_ART_OFFSET + level * HEIGHT_PIXELS)
			data.y_sort_origin = level
	tile_set.add_source(source, 0)
	return tile_set


func _build_catalog(tile_set: TileSet) -> TileCatalog:
	var catalog := TileCatalog.new()
	catalog.tile_set = tile_set
	catalog.fallback_ground_id = &"campo_terra"
	catalog.level_min = LEVEL_MIN
	catalog.level_max = LEVEL_MAX
	catalog.resource_name = "GroundCatalog"
	var entries: Array[GroundTileEntry] = []
	for row in GROUND_ROWS.size():
		var entry := GroundTileEntry.new()
		entry.ground_id = GROUND_ROWS[row]
		entry.source_id = 0
		entry.atlas_coords = Vector2i(0, row)
		entry.alternative_tile = 0
		entry.resource_name = String(GROUND_ROWS[row])
		entries.append(entry)
	catalog.entries = entries
	return catalog
