## Mede, em pixels, por que piso e faces ficam no MESMO Z.
##
## Toda vez que alguém deu um `z_index` próprio ao piso, a intenção foi proteger
## as pernas do personagem — e o efeito colateral foi o terreno recortado. Este
## teste mede as duas coisas de uma vez, com render de verdade:
##
##   1. quantos pixels do personagem sobrevivem à composição, nos dois arranjos;
##   2. quanto o terreno muda quando o piso sai do Z comum.
##
## Requer driver gráfico:
##   godot --path . --resolution 400x300 \
##     --script res://tests/terrain_depth_composition_test.gd
extends SceneTree

const OUTPUT := "user://terrain_depth_composition.png"

var _passed := 0
var _failed := 0


func _check(condition: bool, label: String, detail: String = "") -> void:
	if condition:
		_passed += 1
		print("  ok   %s %s" % [label, detail])
	else:
		_failed += 1
		printerr("  FALHA %s %s" % [label, detail])


func _init() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene: Node = load("res://scenes/main/main.tscn").instantiate()
	root.add_child(scene)
	var interface := scene.get_node_or_null(^"Interface") as CanvasLayer
	if interface != null:
		interface.visible = false
	for name in ["TestBedAnchor", "BedAnchor", "Bed2Anchor", "Bed3Anchor", "TestWallAnchor"]:
		var node := scene.get_node_or_null(NodePath("World/DepthSort/Entities/" + name))
		if node != null:
			node.queue_free()
	var world := scene.get_node(^"World/ProceduralWorld") as ProceduralWorld
	var player := scene.get_node(
		^"World/DepthSort/Entities/PlayerAnchor/Player"
	) as PlayerController
	var visual := scene.get_node(
		^"World/DepthSort/Entities/PlayerAnchor/Player/VisualAnchor"
	) as CanvasItem
	var camera := scene.get_node(
		^"World/DepthSort/Entities/PlayerAnchor/Player/Camera2D"
	) as Camera2D
	camera.zoom = Vector2(2.0, 2.0)
	var agent := player.grid_agent
	agent.respect_physics_obstacles = false
	for frame in 150:
		await process_frame

	print("\n[Composição] piso e faces no mesmo Z")
	_check(world.ground_root.z_index == world.depth_root.z_index,
		"o jogo roda com piso e faces no mesmo Z",
		"ground=%d depth=%d" % [world.ground_root.z_index, world.depth_root.z_index])

	# Três situações: plano, degrau descendo à frente, degrau subindo atrás.
	var data := world.world_data()
	var spots: Array[Vector2i] = []
	for radius in range(1, 26):
		for y in range(-radius, radius + 1):
			for x in range(-radius, radius + 1):
				var cell := Vector2i(x, y)
				var height := data.height_at(cell)
				if spots.size() < 1 and height == data.height_at(cell + Vector2i(1, 1)) \
					and height == data.height_at(cell - Vector2i(1, 1)):
					spots.append(cell)
				if spots.size() < 2 and data.height_at(cell + Vector2i(1, 1)) == height - 1:
					spots.append(cell)
				if spots.size() < 3 and data.height_at(cell - Vector2i(1, 1)) == height + 1:
					spots.append(cell)
		if spots.size() >= 3:
			break
	while spots.size() < 3:
		spots.append(Vector2i.ZERO)

	# Grama e folhas animam. Sem congelar o tempo, a diferença entre duas
	# capturas mede animação, não composição.
	Engine.time_scale = 0.0
	var visible_together := 0
	var visible_split := 0
	var terrain_shift := 0
	var shots: Array[Image] = []
	for split: bool in [false, true]:
		world.ground_root.z_index = -1 if split else 0
		for spot in spots:
			agent.teleport_to(spot)
			for frame in 8:
				await process_frame
			visual.visible = true
			RenderingServer.force_draw()
			var with_actor := root.get_texture().get_image().duplicate()
			visual.visible = false
			RenderingServer.force_draw()
			var terrain := root.get_texture().get_image().duplicate()
			visual.visible = true
			var count := _difference(with_actor, terrain)
			if split:
				visible_split += count
			else:
				visible_together += count
				shots.append(terrain)
		if split:
			# Mesmo enquadramento do primeiro arranjo: o que mudar é composição.
			for index in spots.size():
				agent.teleport_to(spots[index])
				for frame in 8:
					await process_frame
				visual.visible = false
				RenderingServer.force_draw()
				terrain_shift += _difference(
					root.get_texture().get_image(), shots[index]
				)
				visual.visible = true
	world.ground_root.z_index = 0
	Engine.time_scale = 1.0

	# O argumento para separar o Z sempre foi "o piso engole as pernas". Medido,
	# a diferença fica em fração de um por cento — ou seja, não existe. O que
	# existe é o terreno recortado, medido logo abaixo.
	var tolerance := int(float(visible_split) * 0.01)
	_check(visible_together >= visible_split - tolerance,
		"o piso no Z comum NAO engole o personagem",
		"%d px visiveis juntos vs %d separados (tolerancia %d)" % [
			visible_together, visible_split, tolerance
		])
	_check(terrain_shift > 0,
		"tirar o piso do Z comum realmente altera o terreno",
		"%d px de diferenca" % terrain_shift)

	if not shots.is_empty():
		var width := shots[0].get_width()
		var height := shots[0].get_height()
		var sheet := Image.create_empty(
			width * shots.size(), height, false, shots[0].get_format()
		)
		for index in shots.size():
			sheet.blit_rect(
				shots[index], Rect2i(Vector2i.ZERO, shots[index].get_size()),
				Vector2i(index * width, 0)
			)
		sheet.save_png(OUTPUT)
		print("  preview: ", ProjectSettings.globalize_path(OUTPUT))

	print("\n==== %d passaram, %d falharam ====" % [_passed, _failed])
	quit(1 if _failed > 0 else 0)


func _difference(a: Image, b: Image) -> int:
	var count := 0
	for y in a.get_height():
		for x in a.get_width():
			if a.get_pixel(x, y) != b.get_pixel(x, y):
				count += 1
	return count
