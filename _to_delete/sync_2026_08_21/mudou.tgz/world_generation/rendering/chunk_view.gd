## Representação VISUAL de um chunk. Não guarda regra de jogo.
##
## Cada nível usado recebe uma camada Ground (superfícies, z = -1) e, quando
## necessário, camadas Depth (faces verticais e tampas frontais, z = 0 e
## Y-Sort).
##
## [b]Ordenação de profundidade[/b]: o Z só separa as classes Ground, Depth e
## Overlay. Dentro de Depth, faces, estruturas, vegetação e entidades ficam no
## mesmo Z efetivo. A face usa como pivô a borda frontal definida no TileSet.
class_name ChunkView
extends Node2D

@export var height_layer_scene: PackedScene
## Nó vazio usado como âncora de ordenação de árvores e estruturas.
@export var prop_anchor_scene: PackedScene
@export var catalog: TileCatalog
@export var settings: WorldSettings

@onready var ground_layers: Node2D = %GroundLayers
@onready var depth_layers: Node2D = %DepthLayers
@onready var overlay_layers: Node2D = %OverlayLayers
@onready var structures_root: Node2D = %Structures
@onready var decorations_root: Node2D = %Decorations

var chunk_coord: Vector2i = Vector2i.ZERO

var _ground_layers: Dictionary = {}
var _depth_layers: Dictionary = {}
var _depth_cap_layers: Dictionary = {}
var _base_tints: Dictionary = {}
var _visibility_tints: Dictionary = {}
var _owned_depth_nodes: Array[Node] = []
var _owned_ground_cells: Dictionary = {}
var _owned_depth_cells: Dictionary = {}
var _owned_depth_cap_cells: Dictionary = {}
var _uses_shared_layers: bool = false
var _iso: IsoCoordinateSystem
var _world_data: WorldData
var _reference_level: int = 0


func build(
	chunk: ChunkData,
	p_settings: WorldSettings,
	p_catalog: TileCatalog,
	p_ground_root: Node2D = null,
	p_depth_root: Node2D = null,
	p_overlay_root: Node2D = null,
	p_world_data: WorldData = null,
	p_ground_layer_registry: Variant = null,
	p_depth_layer_registry: Variant = null,
	p_depth_cap_layer_registry: Variant = null
) -> void:
	_clear()
	settings = p_settings
	catalog = p_catalog
	chunk_coord = chunk.coord
	_iso = IsoCoordinateSystem.from_settings(settings)
	_world_data = p_world_data
	if p_ground_root != null:
		ground_layers = p_ground_root
	if p_depth_root != null:
		depth_layers = p_depth_root
		structures_root = p_depth_root
		decorations_root = p_depth_root
	if p_overlay_root != null:
		overlay_layers = p_overlay_root
	_uses_shared_layers = p_ground_layer_registry != null
	_ground_layers = p_ground_layer_registry if _uses_shared_layers else {}
	_depth_layers = p_depth_layer_registry if _uses_shared_layers else {}
	_depth_cap_layers = (
		p_depth_cap_layer_registry
		if _uses_shared_layers and p_depth_cap_layer_registry != null
		else {}
	)
	_paint_ground(chunk)


func _exit_tree() -> void:
	# As camadas visuais podem estar nas raízes globais, fora da árvore deste
	# ChunkView. Portanto o unload precisa libertá-las explicitamente.
	_clear()


func _clear() -> void:
	_erase_owned_cells(_ground_layers, _owned_ground_cells)
	_erase_owned_cells(_depth_layers, _owned_depth_cells)
	_erase_owned_cells(_depth_cap_layers, _owned_depth_cap_cells)
	if not _uses_shared_layers:
		for layer: TileMapLayer in _ground_layers.values():
			layer.queue_free()
		for layer: TileMapLayer in _depth_layers.values():
			layer.queue_free()
		for layer: TileMapLayer in _depth_cap_layers.values():
			layer.queue_free()
		_ground_layers.clear()
		_depth_layers.clear()
		_depth_cap_layers.clear()
	for owned: Node in _owned_depth_nodes:
		if is_instance_valid(owned):
			owned.queue_free()
	_owned_depth_nodes.clear()
	_base_tints.clear()
	_visibility_tints.clear()


func _erase_owned_cells(registry: Dictionary, owned: Dictionary) -> void:
	for level: int in owned:
		var layer := registry.get(level, null) as TileMapLayer
		if layer == null:
			continue
		for cell_coord: Vector2i in owned[level]:
			layer.erase_cell(cell_coord)
	owned.clear()


func _remember_cell(owned: Dictionary, level: int, cell_coord: Vector2i) -> void:
	if not owned.has(level):
		var new_cells: Array[Vector2i] = []
		owned[level] = new_cells
	var cells: Array[Vector2i] = owned[level]
	if not cells.has(cell_coord):
		cells.append(cell_coord)


func _paint_ground(chunk: ChunkData) -> void:
	var size := chunk.size
	for y in size:
		for x in size:
			var cell := chunk.get_cell(Vector2i(x, y))
			if cell == null:
				continue
			var cell_coord := Vector2i(cell.world_xy.x, cell.world_xy.y)

			# 1) superfície top-only. Em campo plano ela fica em Ground, atrás das
			# pernas. Se fecha uma face traseira, vai para DepthCap (uma única
			# cópia) para poder recobrir a sobra horizontal daquela face.
			_paint_surface(chunk, cell, cell_coord)

			# 2) faces independentes. Cada lado consulta seu próprio vizinho;
			# portanto uma borda reta não ganha uma lateral fantasma no outro lado.
			_paint_exposed_faces(chunk, cell, cell_coord)

			# 3) superfície de água
			if cell.is_liquid():
				_set_ground_tile(settings.sea_level, cell_coord, settings.water_ground_id)


## Vizinhos frontais na projeção: +Y expõe a face esquerda; +X, a direita.
func _paint_exposed_faces(chunk: ChunkData, cell: WorldCell, cell_coord: Vector2i) -> void:
	var left_height := _front_neighbor_height(chunk, cell, Vector2i(0, 1))
	var right_height := _front_neighbor_height(chunk, cell, Vector2i(1, 0))
	var lowest := mini(left_height, right_height)
	var bottom := maxi(lowest, cell.height - settings.max_wall_depth)
	for level in range(cell.height, bottom, -1):
		var show_left := level > left_height
		var show_right := level > right_height
		if not show_left and not show_right:
			continue
		var mask := TileCatalog.FaceMask.BOTH
		if show_left and not show_right:
			mask = TileCatalog.FaceMask.LEFT
		elif show_right and not show_left:
			mask = TileCatalog.FaceMask.RIGHT
		var tile_id: StringName = cell.ground_id if level == cell.height else cell.wall_id
		_set_depth_face(level, cell_coord, tile_id, mask)


func _front_neighbor_height(chunk: ChunkData, cell: WorldCell, offset: Vector2i) -> int:
	var neighbor := chunk.get_cell_world(cell.world_xy + offset)
	if neighbor != null:
		return neighbor.height
	# Consulta coordenadas globais em vez de inventar um degrau na borda do
	# chunk. WorldData usa o chunk carregado ou o sampler procedural determinista.
	if _world_data != null:
		return _world_data.height_at(cell.world_xy + offset)
	return cell.height


## Uma tampa pertence à própria célula baixa. Ela olha para os dois vizinhos
## TRASEIROS (-X/-Y), isto é, os blocos cujas faces podem invadir seu topo.
## Fazer a consulta deste lado mantém ownership/unload determinístico inclusive
## quando o degrau cruza uma borda de chunk.
func _paint_surface(chunk: ChunkData, cell: WorldCell, cell_coord: Vector2i) -> void:
	var rear_x_height := _neighbor_height(chunk, cell, Vector2i(-1, 0))
	var rear_y_height := _neighbor_height(chunk, cell, Vector2i(0, -1))
	if rear_x_height <= cell.height and rear_y_height <= cell.height:
		_set_ground_tile(cell.height, cell_coord, cell.ground_id)
		return
	_set_depth_cap(cell.height, cell_coord, cell.ground_id)


func _neighbor_height(chunk: ChunkData, cell: WorldCell, offset: Vector2i) -> int:
	var neighbor := chunk.get_cell_world(cell.world_xy + offset)
	if neighbor != null:
		return neighbor.height
	if _world_data != null:
		return _world_data.height_at(cell.world_xy + offset)
	return cell.height


func _set_ground_tile(level: int, cell_coord: Vector2i, ground_id: StringName) -> void:
	if catalog == null:
		return
	var entry := catalog.find(ground_id)
	if entry == null:
		return
	_ground_layer_for(level).set_cell(
		cell_coord,
		entry.source_id,
		entry.atlas_coords,
		catalog.alternative_for(level, _mirrors_top(cell_coord))
	)
	_remember_cell(_owned_ground_cells, level, cell_coord)


## Sorteio ESTÁVEL por célula: recarregar o chunk não pode mudar o desenho.
##
## Não depende da semente do mundo de propósito — espelhar é decoração, não
## conteúdo; assim dois mundos com a mesma semente continuam idênticos e o save
## não precisa guardar nada disso.
func _mirrors_top(cell_coord: Vector2i) -> bool:
	return WorldRandom.value_01(0, cell_coord, 1) < 0.5


func _set_depth_face(
	level: int,
	cell_coord: Vector2i,
	ground_id: StringName,
	mask: TileCatalog.FaceMask
) -> void:
	if catalog == null:
		return
	var entry := catalog.find(ground_id)
	if entry == null:
		return
	_depth_layer_for(level).set_cell(
		cell_coord,
		TileCatalog.DEPTH_FACE_SOURCE_ID,
		catalog.face_atlas_coords(entry, mask),
		catalog.alternative_for(level)
	)
	_remember_cell(_owned_depth_cells, level, cell_coord)


func _set_depth_cap(level: int, cell_coord: Vector2i, ground_id: StringName) -> void:
	if catalog == null:
		return
	var entry := catalog.find(ground_id)
	if entry == null:
		return
	_depth_cap_layer_for(level).set_cell(
		cell_coord,
		entry.source_id,
		entry.atlas_coords,
		catalog.alternative_for(level, _mirrors_top(cell_coord))
	)
	_remember_cell(_owned_depth_cap_cells, level, cell_coord)


## Cria uma camada de altura.
##
## Todas as camadas nascem com z local 0 e Y-Sort. O Z efetivo vem da raiz:
## Ground=-1; faces e tampas ficam em Depth=0. A tampa recebe a única cópia do
## topo necessária para que uma superfície frontal ainda possa recobrir uma
## face traseira sem fazer todo o piso disputar ordenação com as pernas.
func _create_layer(level: int, parent: Node2D, prefix: String) -> TileMapLayer:
	var layer: TileMapLayer = height_layer_scene.instantiate()
	layer.name = "%s_%d" % [prefix, level]
	layer.tile_set = catalog.tile_set
	layer.position = Vector2.ZERO
	layer.z_index = 0
	layer.y_sort_enabled = true
	# A compensação de cada nível pertence ao TileData.y_sort_origin. O layer
	# permanece neutro para não criar uma barreira única entre seus tiles.
	layer.y_sort_origin = 0
	layer.collision_enabled = false
	layer.navigation_enabled = false
	parent.add_child(layer)
	layer.set_meta(&"world_render_class", prefix)
	layer.set_meta(&"world_level", level)
	_sort_global_layers(parent, prefix)
	return layer


func _sort_global_layers(parent: Node2D, prefix: String) -> void:
	# O Y-Sort decide a profundidade entre tiles; a ordem dos nós só resolve
	# empates (mesma célula, níveis diferentes). Ainda assim precisa ser
	# estável: não pode depender de qual worker terminou primeiro.
	var matching: Array[Node] = []
	for child in parent.get_children():
		if child.get_meta(&"world_render_class", "") == prefix:
			matching.append(child)
	matching.sort_custom(func(a: Node, b: Node) -> bool:
		return int(a.get_meta(&"world_level", 0)) < int(b.get_meta(&"world_level", 0))
	)
	for child in matching:
		parent.move_child(child, parent.get_child_count() - 1)


func _ground_layer_for(level: int) -> TileMapLayer:
	if _ground_layers.has(level):
		return _ground_layers[level]
	var layer := _create_layer(level, ground_layers, "Ground")
	_ground_layers[level] = layer
	_apply_tint(level)
	return layer


func _depth_layer_for(level: int) -> TileMapLayer:
	if _depth_layers.has(level):
		return _depth_layers[level]
	var layer := _create_layer(level, depth_layers, "Depth")
	_depth_layers[level] = layer
	_apply_tint(level)
	return layer


func _depth_cap_layer_for(level: int) -> TileMapLayer:
	if _depth_cap_layers.has(level):
		return _depth_cap_layers[level]
	var layer := _create_layer(level, depth_layers, "DepthCap")
	_depth_cap_layers[level] = layer
	_apply_tint(level)
	return layer


func layer_levels() -> Array:
	var levels: Dictionary = {}
	for level in _owned_ground_cells:
		levels[level] = true
	for level in _owned_depth_cells:
		levels[level] = true
	for level in _owned_depth_cap_cells:
		levels[level] = true
	return levels.keys()


func layer_at(level: int) -> TileMapLayer:
	return _ground_layers.get(level, null)


func depth_layer_at(level: int) -> TileMapLayer:
	return _depth_layers.get(level, null)


func depth_cap_layer_at(level: int) -> TileMapLayer:
	return _depth_cap_layers.get(level, null)


## Instancia uma decoração já decidida pelos dados.
func add_decoration(placement: DecorationPlacement) -> Node2D:
	if placement.definition == null or placement.definition.scene == null:
		return null
	var instance: Node2D = placement.definition.scene.instantiate()
	instance.scale = Vector2(
		-placement.scale_factor if placement.flip_h else placement.scale_factor,
		placement.scale_factor
	)
	instance.set_meta(&"object_id", placement.object_id)
	instance.set_meta(&"world_position", placement.world_pos)
	_anchor_prop(instance, placement.world_pos, decorations_root)
	return instance


## Instancia uma estrutura já planejada.
func add_structure(placement: StructurePlacement) -> Node2D:
	if placement.definition == null or placement.definition.scene == null:
		return null
	var instance: Node2D = placement.definition.scene.instantiate()
	var root := instance as StructureRoot
	if root != null:
		root.setup(placement)
	_anchor_prop(
		instance,
		Vector3i(placement.origin_xy.x, placement.origin_xy.y, placement.foundation_height),
		structures_root
	)
	return instance


## Pendura um objeto do mundo em uma âncora posicionada no plano da grade.
##
## A âncora carrega a posição PLANA da célula (é ela que entra no Y-Sort) e o
## objeto recebe só o deslocamento vertical da altura. Sem isso, um objeto em
## cima de um morro seria ordenado como se estivesse mais ao fundo.
func _anchor_prop(prop: Node2D, world_pos: Vector3i, parent: Node2D) -> void:
	var cell := Vector2i(world_pos.x, world_pos.y)
	var anchor: Node2D = (
		prop_anchor_scene.instantiate() if prop_anchor_scene != null else Node2D.new()
	)
	anchor.name = "Anchor_%d_%d" % [cell.x, cell.y]
	anchor.y_sort_enabled = false
	anchor.position = _iso.cell_to_local(cell) + Vector2(0.0, _iso.prop_sort_bias())
	parent.add_child(anchor)
	_owned_depth_nodes.append(anchor)
	anchor.add_child(prop)
	prop.position = Vector2(0.0, -float(world_pos.z * settings.height_pixels) - _iso.prop_sort_bias())
	prop.z_index = 0


## Usado pelo [HeightVisibilityManager]. Não altera dados, só aparência.
##
## A cor recebida é MULTIPLICADA pelo sombreamento de altura da camada, para os
## dois sistemas conviverem sem um apagar o outro.
func apply_level_modulation(level: int, color: Color, layer_visible: bool) -> void:
	if (
		not _ground_layers.has(level)
		and not _depth_layers.has(level)
		and not _depth_cap_layers.has(level)
	):
		return
	_visibility_tints[level] = color
	for layer: TileMapLayer in [
		_ground_layers.get(level, null),
		_depth_layers.get(level, null),
		_depth_cap_layers.get(level, null)
	]:
		if layer != null:
			layer.visible = layer_visible
	_apply_tint(level)


## Nível de referência do sombreamento (normalmente onde o jogador está).
func set_reference_level(level: int) -> void:
	if _reference_level == level:
		return
	_reference_level = level
	for existing_level: int in layer_levels():
		_apply_tint(existing_level)


func reference_level() -> int:
	return _reference_level


func _apply_tint(level: int) -> void:
	if settings == null:
		return
	var base := settings.tint_for_level(level, _reference_level)
	_base_tints[level] = base
	var overlay: Color = _visibility_tints.get(level, Color.WHITE)
	var tint := Color(
		base.r * overlay.r, base.g * overlay.g, base.b * overlay.b, base.a * overlay.a
	)
	for layer: TileMapLayer in [
		_ground_layers.get(level, null),
		_depth_layers.get(level, null),
		_depth_cap_layers.get(level, null)
	]:
		if layer != null:
			layer.modulate = tint
