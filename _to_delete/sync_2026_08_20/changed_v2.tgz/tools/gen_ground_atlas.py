"""Monta os atlas de chão do mundo procedural.

Regras:
  * os 6 tiles de grama são EXATAMENTE os fornecidos, com os 3 frames de
    animação preservados;
  * para cada grama é derivado um bloco de TERRA correspondente, usado nas
    paredes/colunas abaixo da grama. A lateral é copiada pixel a pixel do tile
    original (então casa perfeitamente) e a face de cima é reconstruída a partir
    da paleta de terra daquele mesmo tile;
  * os blocos de terra são ESTÁTICOS (1 frame). Só a arte fornecida anima;
  * a saída gera uma cópia TOP para Ground e uma FACE para Depth. O atlas
    original completo permanece no TileSet apenas para compatibilidade com
    recursos antigos; o renderer atual não precisa de underlay por chunk.
"""
from PIL import Image
import numpy as np
import math
import random
import zlib

# Ajuste para a pasta onde estão os tiles originais.
SRC = '../../Isometric Tiles/Tiles Biomes/'
SRC_ALT = SRC
W, H = 128, 106
DIAMOND_TOP = 16                        # y do topo do losango da face superior
DIAMOND_H = 64
CY = DIAMOND_TOP + DIAMOND_H / 2.0      # 48.0
SKIRT = 26                              # altura da lateral (= height_pixels)

# Cada bioma tem VÁRIAS variantes de grama na pasta original — é o que dá vida
# ao terreno. Todas entram no atlas; o mundo sorteia entre elas em manchas.
# O último item de cada bioma é o usado para derivar o bloco de terra.
BIOMES = [
    ('campo', [
        ('campo_alto',       SRC_ALT + 'Tile Bioma Campo Verde/Campo/frames/'),
        ('campo_mato_denso', SRC_ALT + 'Tile Bioma Campo Verde/Campo Mato Denso/frames/'),
        ('campo_quase_ralo', SRC_ALT + 'Tile Bioma Campo Verde/Campo quase ralo/'),
        ('campo_ralo',       SRC_ALT + 'Tile Bioma Campo Verde/Campo Ralo/frames/'),
        ('campo_baixo',      SRC + 'Tile Bioma Campo Verde/r01_campo_baixo/frames/'),
    ]),
    ('campo_claro', [
        ('claro_denso', SRC + 'Tile Bioma Campo Verde Claro/r02_denso_baixo/frames/'),
        ('claro',       SRC + 'Tile Bioma Campo Verde Claro/r03_clara/frames/'),
    ]),
    ('campo_florido', [
        ('florida',          SRC_ALT + 'Tile Bioma Campo Florida/florida/'),
        ('florida_rasteira', SRC_ALT + 'Tile Bioma Campo Florida/florida_rasteira/'),
        ('florida_baixa',    SRC + 'Tile Bioma Campo Florida/r06_florida_baixa/frames/'),
    ]),
    ('floresta', [
        ('floresta',           SRC_ALT + 'Tile Bioma Floresta/floresta/frames/'),
        ('floresta_rasteira',  SRC_ALT + 'Tile Bioma Floresta/floresta_rasteira/'),
        ('musgo',              SRC + 'Tile Bioma Floresta/r05_musgo/frames/'),
    ]),
    ('savana', [
        ('savana',           SRC_ALT + 'Tile Bioma Savana/Savana/frames/'),
        ('savana_rasteira',  SRC_ALT + 'Tile Bioma Savana/Savana rasteira/'),
        ('savana_baixa',     SRC + 'Tile Bioma Savana/r04_savana_baixa/frames/'),
    ]),
]


def load_frames(folder):
    return [Image.open(folder + 'frame_%d.png' % i).convert('RGBA') for i in (1, 2, 3)]


def diamond_edges(x):
    """(y_topo, y_base) da face superior na coluna x."""
    t = abs(x + 0.5 - 64.0) / 64.0
    half = (DIAMOND_H / 2.0) * (1.0 - t)
    return CY - half, CY + half


# ------------------------------------------------------------------ ruído
def _vnoise(gx, gy, seed):
    h = (int(gx) * 374761393 + int(gy) * 668265263 + seed * 1442695040888963407) & 0xFFFFFFFF
    h = (h ^ (h >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((h ^ (h >> 16)) & 0xFFFF) / 65535.0


def smooth_noise(fx, fy, cell, seed):
    gx, gy = fx / cell, fy / cell
    x0, y0 = math.floor(gx), math.floor(gy)
    tx, ty = gx - x0, gy - y0
    tx = tx * tx * (3 - 2 * tx)
    ty = ty * ty * (3 - 2 * ty)
    v00 = _vnoise(x0, y0, seed);     v10 = _vnoise(x0 + 1, y0, seed)
    v01 = _vnoise(x0, y0 + 1, seed); v11 = _vnoise(x0 + 1, y0 + 1, seed)
    return (v00 * (1 - tx) + v10 * tx) * (1 - ty) + (v01 * (1 - tx) + v11 * tx) * ty


def ramp(colors, t):
    n = len(colors) - 1
    p = max(0.0, min(0.999999, t)) * n
    i = int(p)
    f = p - i
    a, b = colors[i], colors[i + 1]
    return tuple(int(round(a[c] + (b[c] - a[c]) * f)) for c in range(3))


# ---------------------------------------------------- paleta de terra do tile
def skirt_palette(image, steps=5):
    """Paleta de terra extraída da LATERAL do próprio tile.

    São literalmente as cores que o artista usou. Nada de média nem gradiente:
    o bloco de terra é pintado só com elas.
    """
    px = np.array(image)
    samples = []
    for x in range(W):
        _, yb = diamond_edges(x)
        for y in range(int(math.ceil(yb)) + 3, int(yb) + SKIRT - 1):
            if 0 <= y < H and px[y, x, 3] > 200 and not _is_foliage(px[y, x]):
                samples.append(px[y, x, :3].astype(float))
    samples = np.array(samples)
    luma = samples @ np.array([0.299, 0.587, 0.114])
    samples = samples[np.argsort(luma)]
    stops = np.linspace(0.10, 0.97, steps)
    palette = []
    for stop in stops:
        color = samples[int(stop * (len(samples) - 1))]
        palette.append(tuple(int(round(v)) for v in color))
    return palette


def skirt_colors(image, limit=16):
    """Cores DE FATO usadas na lateral do tile, da mais comum para a mais rara.

    Serve para travar qualquer pixel novo em um tom que já existe na arte —
    nada de cor inventada e nada de meio-tom borrado.
    """
    px = np.array(image)
    counts = {}
    for x in range(W):
        _, yb = diamond_edges(x)
        for y in range(int(math.ceil(yb)), H):
            if px[y, x, 3] < 200:
                continue
            if _is_foliage(px[y, x]):
                continue
            key = (int(px[y, x, 0]), int(px[y, x, 1]), int(px[y, x, 2]))
            counts[key] = counts.get(key, 0) + 1
    ordered = sorted(counts.items(), key=lambda kv: -kv[1])
    return [color for color, _count in ordered[:limit]]


def snap(color, palette):
    """Cor mais próxima dentro da paleta da arte original."""
    best = palette[0]
    best_distance = None
    for candidate in palette:
        dr = color[0] - candidate[0]
        dg = color[1] - candidate[1]
        db = color[2] - candidate[2]
        distance = dr * dr + dg * dg + db * db
        if best_distance is None or distance < best_distance:
            best_distance = distance
            best = candidate
    return best


def brighten(color, gain, lift):
    return tuple(min(255, max(0, int(round(c * gain + lift)))) for c in color)


# Dithering ordenado 4x4 (Bayer). É o que dá a "textura de pixel art" em vez de
# um degradê liso de imagem redimensionada.
BAYER4 = [
    [0, 8, 2, 10],
    [12, 4, 14, 6],
    [3, 11, 1, 9],
    [15, 7, 13, 5],
]


def quantize(palette, t, x, y):
    """Escolhe uma cor DA PALETA, com dithering ordenado entre vizinhas."""
    t = max(0.0, min(1.0, t))
    f = t * (len(palette) - 1)
    index = int(math.floor(f))
    frac = f - index
    if frac > (BAYER4[y & 3][x & 3] + 0.5) / 16.0:
        index += 1
    return palette[max(0, min(len(palette) - 1, index))]


def _is_foliage(pixel):
    """Verdadeiro para pixels de vegetação.

    Usa MATIZ, não só "é verde": a grama da savana puxa para o ocre e a sombra
    sob a grama puxa para o verde-azulado. Terra e pedra ficam de fora porque a
    terra tem matiz alaranjada (< 45°) e a pedra é dessaturada.
    """
    r, g, b = float(pixel[0]), float(pixel[1]), float(pixel[2])
    mx, mn = max(r, g, b), min(r, g, b)
    if mx <= 0.0:
        return False
    delta = mx - mn
    if delta / mx < 0.18:
        return False
    if mx == r:
        hue = 60.0 * (((g - b) / delta) % 6.0)
    elif mx == g:
        hue = 60.0 * (((b - r) / delta) + 2.0)
    else:
        hue = 60.0 * (((r - g) / delta) + 4.0)
    return 45.0 <= hue <= 200.0


def make_dirt_block(name, source_frame):
    """Bloco de terra que combina com o tile de grama informado.

    A lateral é copiada pixel a pixel do original — é isso que faz a coluna de
    terra encaixar embaixo da grama sem a grama parecer flutuando.
    """
    src = np.array(source_frame)
    out = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    px = out.load()
    palette = skirt_palette(source_frame)
    # A face de cima recebe mais luz que a lateral, mas continua usando as
    # mesmas cores da arte, só deslocadas — nada de tons inventados.
    top_palette = [brighten(c, 1.30, 12) for c in palette]
    # `hash(str)` do Python recebe um salt aleatório por processo. Usá-lo aqui
    # fazia o atlas mudar a cada execução da ferramenta mesmo sem alterar
    # entrada alguma. CRC32 é estável em todas as máquinas/processos.
    stable_seed = zlib.crc32(name.encode('utf-8')) & 0xFFFFFFFF
    rnd = random.Random(stable_seed)
    seed = stable_seed & 0xFFFF

    # --- face superior: ruído em blocos + dithering ordenado
    for x in range(W):
        yt, yb = diamond_edges(x)
        for y in range(int(math.floor(yt)), int(math.ceil(yb))):
            if y < 0 or y >= H:
                continue
            u = (x + 0.5 - 64.0) / 64.0
            v = (y + 0.5 - CY) / 32.0
            # Coordenadas "de superfície": desfaz a projeção para a textura não
            # sair esticada na diagonal.
            sx = u * 64.0 + v * 64.0
            sy = v * 64.0 - u * 64.0
            # Grão fino domina, para a face de cima ter a mesma densidade de
            # pixel da lateral do artista (e não manchas grandes e lisas).
            n = (0.26 * smooth_noise(sx, sy, 11.0, seed)
                 + 0.30 * smooth_noise(sx, sy, 4.0, seed + 31)
                 + 0.28 * smooth_noise(sx, sy, 1.8, seed + 77)
                 + 0.16 * smooth_noise(sx, sy, 1.0, seed + 131))
            t = 0.12 + 0.76 * n
            t += 0.10 * (-v) - 0.04 * u          # luz vinda do topo-esquerdo
            c = quantize(top_palette, t, x, y)
            px[x, y] = (c[0], c[1], c[2], 255)

    # --- pedrinhas, no mesmo espírito das que existem na lateral da arte
    pebble_dark = palette[1]
    pebble_light = brighten(palette[-1], 1.05, 10)
    for _ in range(rnd.randint(5, 8)):
        sxp = rnd.uniform(-0.62, 0.62)
        syp = rnd.uniform(-0.62, 0.62)
        cx = int(64 + (sxp - syp) * 44.0)
        cy = int(CY + (sxp + syp) * 22.0)
        shape = rnd.choice([
            [(0, 0), (1, 0)],
            [(0, 0), (1, 0), (0, 1)],
            [(0, 0)],
        ])
        for dx, dy in shape:
            gx, gy = cx + dx, cy + dy
            if not (0 <= gx < W):
                continue
            top_y, bottom_y = diamond_edges(gx)
            if top_y <= gy < bottom_y:
                px[gx, gy] = (pebble_dark[0], pebble_dark[1], pebble_dark[2], 255)
        top_y, bottom_y = diamond_edges(cx) if 0 <= cx < W else (0.0, -1.0)
        if 0 <= cx < W and top_y <= cy - 1 < bottom_y:
            px[cx, cy - 1] = (pebble_light[0], pebble_light[1], pebble_light[2], 255)

    max_fringe = 14
    art_colors = skirt_colors(source_frame)
    for x in range(W):
        _, yb = diamond_edges(x)
        start = int(math.ceil(yb))
        bottom = H - 1
        while bottom > start and src[bottom, x, 3] == 0:
            bottom -= 1

        # Até onde a grama do tile original invade a lateral.
        fringe_end = start - 1
        for y in range(start, min(start + max_fringe, H)):
            if src[y, x, 3] == 0:
                continue
            if _is_foliage(src[y, x]):
                fringe_end = y
        # As duas primeiras linhas entram sempre: na arte original são a sombra
        # sob a grama e, num bloco de terra puro, virariam um risco solto.
        fringe_end = max(fringe_end, start + 1)

        for y in range(start, H):
            if src[y, x, 3] == 0:
                continue
            if y > fringe_end:
                # Terra original: cópia pixel a pixel.
                px[x, y] = tuple(int(v) for v in src[y, x])
                continue

            # Faixa que era grama: em vez de esticar um pixel (o que vira
            # borrão), a textura de terra logo abaixo é ESPELHADA para cima.
            # Assim o granulado e o dithering do artista continuam, e a cor é
            # travada na paleta da própria arte.
            depth = fringe_end - y + 1
            mirror_y = fringe_end + depth
            span = bottom - fringe_end
            if span > 0:
                # Vai e volta, para não repetir um padrão óbvio nem estourar.
                offset = (depth - 1) % (2 * span)
                if offset >= span:
                    offset = 2 * span - offset - 1
                mirror_y = fringe_end + 1 + offset
            mirror_y = max(start, min(bottom, mirror_y))
            sample = src[mirror_y, x]
            if _is_foliage(sample) or sample[3] == 0:
                sample = src[min(bottom, fringe_end + 1), x]
            # O topo da lateral pega mais luz que o pé: um leve degrau de
            # brilho devolve o volume do bloco.
            gain = 1.0 + 0.030 * float(depth)
            lit = tuple(min(255, int(round(float(sample[c]) * gain))) for c in range(3))
            c = snap(lit, art_colors)
            px[x, y] = (c[0], c[1], c[2], 255)

    # --- contorno do topo com a cor mais escura DA PALETA (sem multiplicação,
    #     senão aparece um tom que não existe na arte)
    edge = brighten(palette[0], 1.05, 0)
    for x in range(W):
        yt, yb = diamond_edges(x)
        for y in (int(math.floor(yt)), int(math.ceil(yb)) - 1):
            if 0 <= y < H and px[x, y][3]:
                px[x, y] = (edge[0], edge[1], edge[2], 255)
    return out


# ---------------------------------------------------------------- montagem
rows = []
for biome_id, variants in BIOMES:
    for variant_id, folder in variants:
        rows.append((variant_id, load_frames(folder), True))
for biome_id, variants in BIOMES:
    # O bloco de terra sai da última variante do bioma (a "baixa"), que é a de
    # grama mais curta e portanto a de lateral mais limpa.
    base_id, folder = variants[-1]
    base = Image.open(folder + 'frame_1.png').convert('RGBA')
    rows.append((biome_id + '_terra', [make_dirt_block(biome_id, base)], False))

atlas = Image.new('RGBA', (W * 3, H * len(rows)), (0, 0, 0, 0))
for r, (name, frames, _animated) in enumerate(rows):
    for c, frame in enumerate(frames):
        atlas.paste(frame, (c * W, r * H))
out_path = 'assets/world/tiles/ground_atlas.png'
atlas.save(out_path)


def split_top_and_faces(source_atlas, row_count):
    """Separa cada bloco em superfície e laterais expostas.

    O atlas de faces possui três linhas para cada linha lógica do atlas:
    esquerda, direita e ambas. Isso permite que o renderer desenhe somente o
    lado cujo vizinho frontal é mais baixo.
    """
    top_atlas = Image.new('RGBA', source_atlas.size, (0, 0, 0, 0))
    face_atlas = Image.new('RGBA', (W * 3, H * row_count * 3), (0, 0, 0, 0))

    for row in range(row_count):
        for frame in range(3):
            box = (frame * W, row * H, (frame + 1) * W, (row + 1) * H)
            block = source_atlas.crop(box)
            block_px = np.array(block)
            top_px = np.zeros_like(block_px)
            left_px = np.zeros_like(block_px)
            right_px = np.zeros_like(block_px)

            for x in range(W):
                _yt, yb = diamond_edges(x)
                boundary = int(math.ceil(yb))
                # Duplica a linha de contorno: o topo fica atrás da face, então
                # a sobreposição elimina frestas sem alterar a oclusão.
                top_px[:min(H, boundary + 1), x] = block_px[:min(H, boundary + 1), x]
                if boundary < H:
                    # Uma fatia visual representa exatamente um Z-Level. A
                    # saia original é mais alta que SKIRT e dependia
                    # de outro bloco completo desenhado à frente para esconder
                    # o excesso. Depois de separar Ground/Depth isso não
                    # acontece mais: o excesso invade o patamar inferior e
                    # vira as faixas horizontais desconectadas. Recortar pela
                    # altura lógica faz fatias consecutivas se encontrarem sem
                    # sobreposição nem buracos.
                    face_bottom = min(H, boundary + SKIRT)
                    if x < W // 2:
                        left_px[boundary:face_bottom, x] = block_px[boundary:face_bottom, x]
                    else:
                        right_px[boundary:face_bottom, x] = block_px[boundary:face_bottom, x]

            top_frame = Image.fromarray(top_px, 'RGBA')
            left_frame = Image.fromarray(left_px, 'RGBA')
            right_frame = Image.fromarray(right_px, 'RGBA')
            both_frame = Image.alpha_composite(left_frame, right_frame)

            top_atlas.paste(top_frame, (frame * W, row * H))
            for face_kind, face_frame in enumerate((left_frame, right_frame, both_frame)):
                face_atlas.paste(face_frame, (frame * W, (row * 3 + face_kind) * H))

    top_atlas.save('assets/world/tiles/ground_top_atlas.png')
    face_atlas.save('assets/world/tiles/depth_face_atlas.png')
    return top_atlas, face_atlas


top_atlas, face_atlas = split_top_and_faces(atlas, len(rows))

print('atlas', atlas.size, '->', out_path)
print('top atlas', top_atlas.size, '-> assets/world/tiles/ground_top_atlas.png')
print('face atlas', face_atlas.size, '-> assets/world/tiles/depth_face_atlas.png')
print('ANIMATED_ROWS =', sum(1 for _n, _f, a in rows if a))
print('GROUND_ROWS = [')
for i, (n, f, a) in enumerate(rows):
    print('    &"%s",%s# linha %2d  %s' % (
        n, ' ' * max(1, 24 - len(n)), i, 'animado' if a else 'estatico'))
print(']')
