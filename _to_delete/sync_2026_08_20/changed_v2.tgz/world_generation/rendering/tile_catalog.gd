## Catálogo que traduz ids lógicos em coordenadas do TileSet.
##
## É aqui — e só aqui — que "dado" vira "tile". Trocar a arte do mundo inteiro
## significa trocar este `.tres`, sem tocar em geração, IA ou save.
##
## [b]Altura e ordenação[/b]: Ground e Depth usam fontes separadas. A fonte 0
## contém superfícies top-only; a fonte 1 contém faces esquerda/direita/ambas;
## e a fonte 2 conserva os blocos completos apenas para compatibilidade de
## recursos/ferramentas. O renderer atual não desenha underlays por chunk: eles
## reintroduziriam barreiras de ordenação. O Z-Level nunca vira `z_index`.
class_name TileCatalog
extends Resource

enum FaceMask {
	LEFT,
	RIGHT,
	BOTH,
}

const GROUND_SOURCE_ID := 0
const DEPTH_FACE_SOURCE_ID := 1
const GROUND_UNDERLAY_SOURCE_ID := 2

@export var tile_set: TileSet
@export var entries: Array[GroundTileEntry] = []
## Usado quando um id não está catalogado (evita mundo invisível por engano).
@export var fallback_ground_id: StringName = &"campo_terra"

@export_group("Alturas suportadas")
## Menor nível com alternativa gerada no TileSet.
@export var level_min: int = -16
## Maior nível com alternativa gerada no TileSet.
@export var level_max: int = 24

var _lookup: Dictionary = {}


func _ensure_lookup() -> void:
	if not _lookup.is_empty():
		return
	for entry in entries:
		if entry != null:
			_lookup[entry.ground_id] = entry


func find(ground_id: StringName) -> GroundTileEntry:
	_ensure_lookup()
	if _lookup.has(ground_id):
		return _lookup[ground_id]
	if _lookup.has(fallback_ground_id):
		return _lookup[fallback_ground_id]
	return null


func has(ground_id: StringName) -> bool:
	_ensure_lookup()
	return _lookup.has(ground_id)


## Id da alternativa que desenha o tile no nível informado.
func alternative_for(level: int) -> int:
	return 1 + clampi(level, level_min, level_max) - level_min


func supports_level(level: int) -> bool:
	return level >= level_min and level <= level_max


func face_atlas_coords(entry: GroundTileEntry, mask: FaceMask) -> Vector2i:
	return Vector2i(entry.atlas_coords.x, entry.atlas_coords.y * 3 + int(mask))


func rebuild() -> void:
	_lookup.clear()
	_ensure_lookup()
