# Relatório — Mundo isométrico procedural do PathLife

Implementação do tutorial `tutorial_mundo_isometrico_procedural_godot_4_6.md`
adaptada ao projeto PathLife (Godot 4.6), respeitando as regras do projeto:
**tudo que é previsível vive em cenas `.tscn` e recursos `.tres`; código só cria
nó quando o conteúdo é realmente dinâmico (e mesmo aí, instanciando uma cena
reutilizável).**

---

## 1. O que foi entregue, em uma frase

Um mundo praticamente infinito, gerado em chunks fora da main thread, com altura
positiva e negativa, 12 biomas grandes com transição gradual, relevo
independente do bioma, estruturas que **o terreno se adapta a elas**, vegetação
data-driven, renderização por `TileMapLayer` com blocos empilhados, movimento em
grade `Vector3i` estilo Minecraft, pathfinding e save incremental — tudo
configurável pelo Inspector.

---

## 2. Arquitetura

```text
                       WorldSettings (.tres)
                               │
                         WorldSampler
              (clima + bioma + relevo, coordenada MUNDIAL)
                               │
     ┌───────────────┬─────────┴─────────┬───────────────┐
     ▼               ▼                   ▼               ▼
 ClimatePass     BiomePass          HeightPass     StructurePass
                                                    + TerrainAdapter
                               │
                        TerrainPass → WaterPass → DecorationPass
                               │
                          ChunkData  (DADOS)
                               │
        ┌──────────────────────┼──────────────────────┐
        ▼                      ▼                      ▼
   ChunkView            WorldData/Navigation     WorldSaveManager
   (TileMapLayer,       (MovementRules,          (semente + patches)
    cenas de árvore,     A*, WorldGridAgent)
    cenas de estrutura)
```

Regra que sustenta tudo: **o `TileMapLayer` nunca é a fonte da verdade.** Ele
desenha o que o `WorldData` diz. Trocar a arte do mundo inteiro é trocar um
`.tres` (o `TileCatalog`), sem tocar em geração, IA ou save.

---

## 3. Arquivos criados

### 3.1 Scripts — `res://world_generation/`

| Pasta | Arquivo | Papel |
|---|---|---|
| `core/` | `world_settings.gd` | **Resource** com toda a configuração global (chunk, raio, alturas, threads). |
| | `world_random.gd` | Sub-sementes determinísticas por sistema (`terrain`, `climate`, `structures`…). |
| | `iso_coordinate_system.gd` | **Único** lugar que conhece a projeção isométrica. |
| | `chunk_math.gd` | World ↔ Chunk ↔ Local ↔ Região (correto com negativos). |
| | `world_cell.gd` | A célula lógica (altura, bioma, relevo, caminhável, líquido…). |
| | `world_data.gd` | Camada de leitura do mundo carregado. Fonte da verdade do gameplay. |
| | `world_sampler.gd` | Clima+bioma+relevo em qualquer coordenada, independente de chunk. |
| | `generation_context.gd` | Contexto passado de passe em passe. |
| | `world_generation_pass.gd` | Interface (abstrata) de um passe da pipeline. |
| | `world_generator.gd` | Executa a pipeline; sabe se clonar para thread. |
| `climate/` | `climate_sample.gd`, `climate_generator.gd` | Temperatura, umidade, continentalidade, "weirdness". |
| | `biome_definition.gd` | **Resource** de bioma. |
| | `biome_resolver.gd` | Pontua todos os biomas e escolhe principal + secundário. Sem cadeia de `if`. |
| `terrain/` | `height_generator.gd` | Relevo por `FastNoiseLite` (continente + elevação + montanha + detalhe). |
| | `terrain_definition.gd`, `terrain_resolver.gd` | Relevo (plano/colina/montanha/penhasco) **independente** do bioma. |
| `passes/` | `01..07` | `ClimatePass`, `BiomePass`, `HeightPass`, `StructurePass`, `TerrainPass`, `WaterPass`, `DecorationPass`. |
| `structures/` | `structure_definition.gd` | **Resource** com footprint, spawn, biomas permitidos e modo de adaptação. |
| | `structure_placement.gd` | Estrutura já decidida (dado puro). |
| | `structure_planner.gd` | Planeja por **região** (4×4 chunks), nunca por chunk. |
| | `structure_root.gd` | Raiz `@tool` da cena da construção, com gizmo de footprint no editor. |
| | `structure_marker.gd` | `Marker2D` tipado: ENTRANCE, ROAD, NPC_SPAWN, DELIVERY, INTERACTION, CUSTOM. |
| | `terrain_adapter.gd` | Achata o footprint e mistura a borda (`smoothstep`) — nada de paredão artificial. |
| `decoration/` | `decoration_definition.gd`, `decoration_placement.gd` | Vegetação e objetos espalhados por dados. |
| `rendering/` | `tile_catalog.gd`, `ground_tile_entry.gd` | Traduz id lógico → tile do TileSet. |
| | `chunk_view.gd` | Visual de um chunk: uma `TileMapLayer` por nível de altura. |
| | `height_visibility_manager.gd` | Esconde/esmaece níveis acima do jogador **sem alterar dados**. |
| `chunks/` | `chunk_data.gd` | Dados do chunk (não é Node → pode nascer em worker thread). |
| | `chunk_manager.gd` | Streaming: pede, gera em `WorkerThreadPool`, integra e descarrega. |
| `navigation/` | `movement_rules.gd` | **Regra única** de movimento (+1 sobe, −1 desce, +2 bloqueia, queda). |
| | `movement_context.gd` | Capacidades da entidade (nadar, escalar, degrau máximo). |
| | `world_navigation.gd` | A* sobre a grade lógica, sempre consultando `MovementRules`. |
| `agents/` | `world_grid_agent.gd` | Dá posição lógica `Vector3i` a qualquer `Node2D` e anima o passo. |
| `saving/` | `cell_patch.gd`, `world_save_manager.gd` | Save incremental: semente + diferenças + objetos removidos. |

### 3.2 Cenas

| Cena | O que é |
|---|---|
| `world_generation/rendering/height_layer.tscn` | `TileMapLayer` configurada (Y-Sort + filtro nearest). Instanciada por nível. |
| `world_generation/rendering/chunk_view.tscn` | `ChunkView` com `HeightLayers` / `Structures` / `Decorations`. |
| `scenes/world/procedural_world.tscn` | O mundo pronto para instanciar: `ChunkContainer` + `ChunkManager` + `HeightVisibility` + `SaveManager`. |
| `scenes/world/world_demo.tscn` | Laboratório autônomo (F6): mundo + ator em grade + HUD de debug. |
| `presentation/world/vegetation/arvore_*.tscn` | 6 árvores (álamo, baobá, ipê, palmeira, salgueiro, sequoia). |
| `presentation/world/structures/deck_madeira.tscn` | Estrutura de exemplo 4×4 com `StructureRoot` e 3 marcadores. |

### 3.3 Recursos gerados (`res://data/world/`) — 49 `.tres`

`world_settings`, `world_sampler`, `world_generator`, `climate_generator`,
`height_generator`, `biome_resolver`, `terrain_resolver`, `structure_planner`,
`player_movement_context`, 9 ruídos, **5 biomas** (um por pasta de bioma da
arte), **16 variantes de grama**, 4 terrenos, 6 decorações, 1 estrutura,
7 passes, `tiles/ground_tileset` e `tiles/ground_catalog`.

Os biomas são `campo_claro`, `campo`, `floresta`, `campo_florido` e `savana` —
o espaço climático (temperatura × umidade) é repartido entre eles, cada um com
o seu bloco de terra em `wall_id` e a sua lista de variantes.

**Variantes em manchas.** Dentro de um bioma, a variante de grama de cada célula
é escolhida por um ruído próprio (`ground_variation`, manchas de ~26 células com
detalhe fino de ~7 para esfarelar as bordas). O resultado são áreas contíguas de
mato fechado, grama rala e rasteira em vez de um chuvisco célula a célula. A
ordem do array `ground_variants` define quem faz fronteira com quem: ele é
percorrido conforme o ruído sobe, então vale listar da mais densa para a mais
rala.

A água está **desligada** (`sea_level = min_height` e o passe de água com
`enabled = false`), porque não há arte de água. O sistema continua no lugar:
basta catalogar um tile de água e reativar.

Todos foram criados pela ferramenta `tools/build_world_resources.gd` e são
recursos normais: **a partir de agora, edite pelo Inspector**.

### 3.4 Arte

| Arquivo | Origem |
|---|---|
| `assets/world/tiles/ground_atlas.png` (384×1272) | Atlas 3 colunas × 12 linhas. |
| `assets/world/vegetation/arvore_*.png` | Copiados da pasta *Isometric Tiles* (`arvores/*_var1`). |
| `assets/world/structures/piso_madeira.png` | `Tile Floor Wood Home/sala/sala_bloco.png`. |

**Linhas 0–15 — as 16 variantes de grama que você desenhou, intactas e animadas
(3 frames cada).** A pasta original tem várias artes por bioma e todas entram:

| Bioma (pasta) | Variantes |
|---|---|
| Campo Verde | `campo_alto`, `campo_mato_denso`, `campo_quase_ralo`, `campo_ralo`, `campo_baixo` |
| Campo Verde Claro | `claro_denso`, `claro` |
| Campo Florida | `florida`, `florida_rasteira`, `florida_baixa` |
| Floresta | `floresta`, `floresta_rasteira`, `musgo` |
| Savana | `savana`, `savana_rasteira`, `savana_baixa` |

**Linhas 16–20 — o bloco de TERRA de cada bioma, estático:** `campo_terra`,
`campo_claro_terra`, `campo_florido_terra`, `floresta_terra`, `savana_terra`.

Cada bloco de terra é derivado do tile de grama correspondente:

* a **lateral é cópia pixel a pixel** do tile original (só os tufos de grama que
  caíam sobre ela são substituídos), então a coluna encaixa perfeitamente
  embaixo da grama — era a falta disso que fazia a grama parecer flutuando em
  desníveis de dois ou mais níveis;
* a **face de cima** é pintada com a paleta de terra extraída da própria lateral
  daquele tile (5 cores, nada inventado), com ruído em blocos, dithering
  ordenado 4×4 e pedrinhas — pixel art de verdade, não textura redimensionada;
* **não animam**: só a arte que você forneceu anima.

Só existem tiles derivados da sua arte. Não há areia, pedra, neve nem água
inventadas.

### 3.5 Ferramentas e testes

| Arquivo | Uso |
|---|---|
| `tools/build_world_resources.gd` | Recria todos os `.tres` do zero. |
| `tools/screenshot_runner.gd` | Roda N frames e salva um print (usado para validar visual). |
| `tests/world_generation_test.gd` | 50 verificações de lógica pura. |
| `tests/player_grid_integration_test.gd` | 21 verificações com `SceneTree` real. |

---

## 4. Decisões técnicas que valem registro

### 4.1 Geometria do tile
A sua arte de chão tem **128×106 px**: o losango de topo (128×64) começa em
`y = 16` e a saia de terra tem **26 px**. Por isso:

* `TileSet.tile_size = (128, 64)`, formato isométrico, layout *diamond down*;
* cada tile do atlas usa `texture_origin = (0, −5)` (sem isso o chão fica
  desalinhado da grade);
* `WorldSettings.height_pixels = 26` — igual à saia. Assim **um degrau de 1
  nível encaixa perfeitamente**, sem sobreposição nem fresta.

### 4.2 Ordenação de profundidade — como funciona (e por que não é `z_index`)

Na projeção isométrica, o que está mais perto da câmera é o que tem maior
`x + y`. A altura é só desempate. Então **a chave de ordenação é a posição PLANA
da célula**, nunca a posição visual (que já subiu com a altura).

Consequências no código:

* todas as `TileMapLayer` ficam em `position = 0` e `z_index = 0`;
* o deslocamento vertical de cada nível vive no **`texture_origin`** de uma
  *alternative tile* por altura (`texture_origin.y = -5 + nível × 26`);
* o nível vai para o **`y_sort_origin`** da mesma alternativa, o que empilha a
  coluna de uma célula (paredes embaixo, topo em cima, água por último) na
  ordem certa;
* árvores e estruturas nascem dentro de uma **âncora** (`prop_anchor.tscn`)
  posicionada no plano, e recebem a altura como deslocamento local;
* entidades usam a mesma ideia: o `WorldGridAgent` põe a posição plana na
  âncora (grupo `grid_sort_anchor`) e a altura no corpo.

Assim o mundo inteiro — terreno, vegetação, estruturas e jogador — cai em um
único Y-Sort ordenado por profundidade real.

> **Tentativa anterior, que estava errada:** uma `TileMapLayer` por nível
> deslocada em `y = -nível × 26` com `z_index = nível`. Como `z_index` tem
> prioridade sobre o Y-Sort, **qualquer terreno mais alto era desenhado por cima
> do jogador, inclusive o que estava atrás dele** — o corpo aparecia cortado por
> um paredão que deveria estar ao fundo. E, como a altura entrava na posição do
> nó, a entidade em cima de um morro era ordenada como se estivesse mais ao
> fundo. Há testes de regressão cobrindo os dois casos.

### 4.2.1 Leitura de altura

Dois blocos vizinhos com um nível de diferença têm exatamente a mesma arte —
sem ajuda, o jogador não percebe o degrau. Foram adicionados:

* **sombreamento por altura relativo ao jogador**: o nível em que ele está fica
  com a **cor original**, sem multiplicação nenhuma; os de baixo escurecem e
  esfriam (10,5% por nível) e os de cima recebem uma atenuação mais leve e
  levemente quente (6,5% por nível). O passo é POR NÍVEL — um degradê absoluto
  sobre 20+ níveis daria menos de 3% e seria invisível. Configurável em
  `WorldSettings` → *Leitura de altura*;
* **sombra de contato** (`presentation/world/entity_shadow.tscn`) sob as
  entidades, para ancorar o personagem no chão. É uma elipse isométrica com
  contorno em xadrez na cor `(40, 34, 52)` — o mesmo estilo (e a mesma cor) das
  sombras que já existem sob as suas árvores, gerada por
  `tools/gen_entity_shadow.py`;
* o recorte correto do corpo pelo terreno da frente, que agora funciona e é o
  que comunica "estou um nível abaixo".

### 4.3 Paredes de desnível
Além do bloco de topo, o `ChunkView` empilha blocos de parede (`wall_id` do
bioma) do nível `h−1` até a altura do vizinho da frente mais baixo, limitado por
`WorldSettings.max_wall_depth`. Desníveis grandes viram penhascos sólidos em vez
de buracos.

### 4.4 Thread safety (armadilha do Godot 4.4+)
`Resource.duplicate(true)` **não copia mais sub-recursos externos** (os que têm
arquivo `.tres` próprio) nem objetos dentro de arrays. Isso faria todas as
"cópias" do gerador compartilharem os mesmos `FastNoiseLite` — disputa entre
threads e mundo errado.

Por isso existem `WorldGenerator.clone()`, `WorldGenerationPass.clone_pass()` e
`WorldSampler.clone_for_thread()`: a clonagem é explícita e copia exatamente o
que tem estado (os ruídos), compartilhando de propósito o que é somente leitura
(biomas, terrenos, cenas). Há teste automatizado cobrindo isso.

### 4.5 Estruturas nascem antes do terreno final
`StructurePass` roda **antes** de `TerrainPass`/`WaterPass`. O planejamento é por
região (4×4 chunks), então uma estrutura na borda aparece no plano dos dois
chunks vizinhos, mas só é **instanciada** pelo chunk que contém a origem do
footprint — nunca duplica. O `TerrainAdapter` achata o footprint e mistura a
borda com `smoothstep`.

### 4.6 O jogador virou grade `Vector3i`
`PlayerController` ganhou `@export var grid_agent: WorldGridAgent`. Com o agente
ligado (é o padrão em `player.tscn`), o movimento é célula a célula e passa
obrigatoriamente por `MovementRules`. Sem ele, o controlador cai no movimento
livre antigo — útil em cenas de teste sem mundo.

Toda a API pública anterior foi preservada (`locomotion_changed`,
`crouch_changed`, `sleep_changed`, `health_changed`, `set_controls_enabled`,
`enter_sleep`, `exit_sleep`, `damage`, `heal`…), então HUD, customização e o
sistema de cama continuam funcionando. O agente ainda consulta a física
(`test_move`) antes de andar, então camas e paredes `StaticBody2D` continuam
bloqueando o passo.

---

## 5. Resultado dos testes

```
tests/world_generation_test.gd          →  50 passaram, 0 falharam
tests/player_grid_integration_test.gd   →  21 passaram, 0 falharam
```

Cobertura: coordenadas negativas, igualdade `IsoCoordinateSystem` ×
`TileMapLayer.map_to_local`, regras de degrau/queda/água, pontuação e alcance
dos 12 biomas, mistura do `TerrainAdapter`, determinismo por semente, ausência
de costura entre chunks, pipeline completa (relevo variado, biomas, relevos,
vegetação, água), estabilidade do planejamento por região, não-duplicação de
estruturas, terreno achatado sob o footprint, A* respeitando as regras, save
incremental, e — no teste de integração — carregamento/descarregamento de
chunks, sincronia entre views e dados, e o jogador andando de fato.

Além disso o mundo foi renderizado de verdade (OpenGL, 1600×900) em três
situações — campo com estruturas, terreno acidentado com neve e uma costa com
praia/savana/oceano — para conferir alinhamento, empilhamento e ordenação.

---

## 5.1 Medição com o personagem real

A perspectiva foi validada com o `character_visual.tscn` do projeto — o rig
cutout completo, com camisa, calça, sapato e cabelo — e não com um retângulo de
teste. O personagem foi renderizado isolado, com a origem no centro da tela, e
medido em pixels:

| Medida | Valor |
|---|---|
| Altura total | 81 px |
| Largura total | 28 px |
| Topo (cabeça) | −70 px da origem |
| **Base (sola do sapato)** | **+10 px da origem** |

Ou seja: **a origem do rig fica no tornozelo, e os pés passam 10 px dela.** Como
o mundo posiciona a entidade pelo centro da célula, o personagem fica com a sola
levemente à frente do centro do losango — o que lê bem em vista isométrica.

A consequência prática é a sombra: centrada na origem ela flutuaria na altura do
tornozelo. Por isso `entity_shadow.tscn` vem com `position = (0, 10)` — o
deslocamento medido. Se você preferir a sola exatamente no centro do losango,
suba o `VisualAnchor` do `player.tscn` em −10 px e zere a posição da sombra.

Os três casos foram conferidos em tela com o personagem real:

* terreno **mais alto atrás** → o corpo aparece inteiro, nada o corta;
* terreno **mais alto à frente** → as pernas são recortadas pela borda do
  degrau, que é o que comunica "estou um nível abaixo";
* **subindo um degrau** → a interpolação separa plano e altura, então o corpo
  sobe durante o passo em vez de saltar no fim, e a ordenação não pisca.

---

## 6. Limitações conhecidas / próximos passos

0. **A ordenação assume `max_height` menor que 16.** O viés de Y-Sort dos
   objetos é um quarto do tile (16 px) e precisa ser maior que o maior
   `y_sort_origin` de tile em uma célula. O padrão (`max_height = 14`) está
   dentro da folga, e há teste garantindo.
1. **Tiles de transição de bioma não estão ligados.** A pasta
   *Tile Transicao de Bioma* tem 4 conjuntos completos (12 peças cada). O dado
   necessário já existe em cada célula (`secondary_biome_id` e `biome_blend`);
   falta a camada de overlay no `ChunkView`. Está descrito no tutorial.
2. **Móveis da cena `main` não sabem a altura do terreno.** As camas continuam em
   posição fixa com `z_index = 0`, então convivem bem com o nível 0. Para
   apoiá-las no relevo, basta dar a elas um `WorldGridAgent` também.
3. **`HeightVisibilityManager` vem desligado** (`enabled = false`): ligado, ele
   esconde montanhas acima do jogador. Ligue quando entrar em interiores/subsolo.
4. **Rios, estradas, cavernas e minérios** não foram implementados — a pipeline
   já tem o encaixe (basta um novo `WorldGenerationPass`).
5. A arte procedural dos 6 chãos novos é boa como base, mas não tem o carinho da
   sua pixel art. Substituir é trocar linhas do atlas.
