## Amostrador global do mundo.
##
## Concentra clima + bioma + relevo base em um único recurso, para que TODOS os
## sistemas (passes, planejador de estruturas, minimapa, debug) enxerguem
## exatamente os mesmos valores em qualquer coordenada mundial, sem depender de
## chunk. É o que garante continuidade entre chunks e determinismo.
class_name WorldSampler
extends Resource

@export var climate: ClimateGenerator
@export var biome_resolver: BiomeResolver
@export var height_generator: HeightGenerator
@export var terrain_resolver: TerrainResolver

@export_group("Variação de chão")
## Ruído que define as MANCHAS de variante de grama dentro de um bioma.
@export var variation_noise: FastNoiseLite
## Tamanho das manchas grandes, em células.
@export_range(2.0, 512.0, 1.0) var variation_scale: float = 26.0
## Tamanho do detalhe que quebra a borda das manchas.
@export_range(1.0, 128.0, 1.0) var variation_detail_scale: float = 7.0
@export_range(0.0, 1.0, 0.01) var variation_detail_weight: float = 0.28

var _settings: WorldSettings
var _world_seed: int = 0


func prepare(settings: WorldSettings, world_seed: int) -> void:
	_settings = settings
	_world_seed = world_seed
	if climate != null:
		climate.prepare(world_seed)
	if height_generator != null:
		height_generator.prepare(world_seed)
	if variation_noise != null:
		variation_noise.seed = WorldRandom.sub_seed(world_seed, &"ground_variation")


func settings() -> WorldSettings:
	return _settings


func world_seed() -> int:
	return _world_seed


func sample_climate(world_xy: Vector2i) -> ClimateSample:
	if climate == null:
		return ClimateSample.new()
	return climate.sample(world_xy)


func resolve_biome(world_xy: Vector2i) -> BiomeDefinition:
	if biome_resolver == null:
		return null
	return biome_resolver.resolve(sample_climate(world_xy)).primary


## Altura base (antes de qualquer estrutura/estrada). Determinística e global.
func base_height(world_xy: Vector2i) -> int:
	if height_generator == null or _settings == null:
		return 0
	var bias := 0.0
	var amplitude := 1.0
	var biome := resolve_biome(world_xy)
	if biome != null:
		bias = biome.height_bias
		amplitude = biome.height_amplitude
	return height_generator.to_level(
		height_generator.sample_raw(world_xy), _settings, bias, amplitude
	)


## Valor 0..1 que escolhe a variante de grama da célula.
func ground_variation(world_xy: Vector2i) -> float:
	if variation_noise == null:
		return 0.5
	var broad := variation_noise.get_noise_2d(
		float(world_xy.x) / variation_scale, float(world_xy.y) / variation_scale
	)
	var detail := variation_noise.get_noise_2d(
		float(world_xy.x) / variation_detail_scale + 512.0,
		float(world_xy.y) / variation_detail_scale - 512.0
	)
	var mixed := lerpf(broad, detail, variation_detail_weight)
	# O ruído fractal raramente encosta em -1/1: o ganho espalha o valor pela
	# faixa toda, senão as variantes das pontas nunca apareceriam.
	return clampf(mixed * 1.9 * 0.5 + 0.5, 0.0, 1.0)


func roughness(world_xy: Vector2i) -> float:
	if height_generator == null:
		return 0.5
	return height_generator.sample_roughness(world_xy)


## Declive base considerando os 4 vizinhos cardeais (independe de chunk).
func base_slope(world_xy: Vector2i) -> float:
	var height := base_height(world_xy)
	var worst := 0
	for offset: Vector2i in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
		worst = maxi(worst, absi(base_height(world_xy + offset) - height))
	return float(worst)


## Cópia independente, para rodar em outra thread sem disputa.
##
## Atenção: `Resource.duplicate(true)` no Godot 4.4+ só copia sub-recursos
## INTERNOS (os que não têm arquivo próprio). Como aqui todos os recursos são
## arquivos `.tres`, a clonagem precisa ser explícita — é isso que este método
## faz. Biomas e terrenos continuam compartilhados de propósito: são apenas
## leitura.
func clone_for_thread() -> WorldSampler:
	var copy: WorldSampler = duplicate(false)
	if climate != null:
		copy.climate = climate.clone_for_thread()
	if height_generator != null:
		copy.height_generator = height_generator.clone_for_thread()
	if variation_noise != null:
		copy.variation_noise = variation_noise.duplicate(false)
	copy.biome_resolver = biome_resolver
	copy.terrain_resolver = terrain_resolver
	copy.prepare(_settings, _world_seed)
	return copy
