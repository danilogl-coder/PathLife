## Renderiza a cena principal para inspeção da oclusão Ground/Depth.
## Uso:
##   godot --path . --script res://tests/world_depth_preview.gd
## Requer um driver de vídeo porque lê os pixels do viewport.
extends SceneTree

const OUTPUT := "user://world_depth_preview.png"


func _init() -> void:
	_capture.call_deferred()


func _capture() -> void:
	var scene: Node = load("res://scenes/main/main.tscn").instantiate()
	root.add_child(scene)
	var interface := scene.get_node_or_null(^"Interface") as CanvasLayer
	if interface != null:
		interface.visible = false
	for frame in 60:
		await process_frame
	var world := scene.get_node_or_null(^"World/ProceduralWorld") as ProceduralWorld
	var player := scene.get_node_or_null(
		^"World/DepthSort/Entities/PlayerAnchor/Player"
	) as PlayerController
	if world != null and player != null:
		var agent := player.grid_agent
		var data := world.world_data()
		var target := Vector2i.ZERO
		var found := false
		# Procura uma face direita exposta e coloca o ator uma diagonal atrás.
		# Essa é exatamente a configuração que falhava na captura original.
		for y in range(-12, 13):
			for x in range(-12, 13):
				var cliff := Vector2i(x, y)
				if data.height_at(cliff) > data.height_at(cliff + Vector2i(1, 0)):
					target = cliff - Vector2i(1, 0)
					found = true
					break
			if found:
				break
		if found:
			agent.teleport_to(target)
			print("ATOR ATRAS DA FACE EM: ", target)
	for frame in 30:
		await process_frame
	var image := root.get_texture().get_image()
	if image == null:
		printerr("Preview requer execução com driver de vídeo (sem --headless).")
		quit(1)
		return
	var error := image.save_png(OUTPUT)
	if error != OK:
		printerr("Falha ao salvar preview: ", error)
		quit(1)
		return
	print("DEPTH PREVIEW: ", ProjectSettings.globalize_path(OUTPUT))
	quit(0)
