## Único ponto do projeto que conhece a projeção isométrica.
##
## Nenhum outro script deve calcular `(x - y) * largura / 2` na mão. Se um dia
## a projeção mudar, só este arquivo muda.
class_name IsoCoordinateSystem
extends RefCounted

var tile_size: Vector2i
var height_pixels: int


func _init(p_tile_size: Vector2i = Vector2i(128, 64), p_height_pixels: int = 26) -> void:
	tile_size = p_tile_size
	height_pixels = p_height_pixels


static func from_settings(settings: WorldSettings) -> IsoCoordinateSystem:
	return IsoCoordinateSystem.new(settings.tile_size, settings.height_pixels)


## Centro da face superior do tile (x, y) no nível 0, em pixels locais.
##
## Usa a MESMA convenção de `TileMapLayer.map_to_local()` com
## `TILE_LAYOUT_DIAMOND_DOWN` (a célula (0,0) fica centrada em meio tile), para
## que tiles, decoração, estruturas e entidades caiam exatamente na mesma
## grade. Existe um teste automatizado garantindo essa igualdade.
func cell_to_local(cell: Vector2i) -> Vector2:
	return Vector2(
		float(cell.x - cell.y + 1) * float(tile_size.x) * 0.5,
		float(cell.x + cell.y + 1) * float(tile_size.y) * 0.5
	)


## Mesma coisa, considerando a altura lógica Z.
func world_to_local(world_pos: Vector3i) -> Vector2:
	var base := cell_to_local(Vector2i(world_pos.x, world_pos.y))
	base.y -= float(world_pos.z) * float(height_pixels)
	return base


## Deslocamento vertical em pixels de um nível de altura.
func height_offset(level: int) -> Vector2:
	return Vector2(0.0, -float(level) * float(height_pixels))


## Converte um ponto de tela/local para a célula do chão no nível informado.
func local_to_cell(local_pos: Vector2, level: int = 0) -> Vector2i:
	var p := local_pos
	p.y += float(level) * float(height_pixels)
	var half_w := float(tile_size.x) * 0.5
	var half_h := float(tile_size.y) * 0.5
	p -= Vector2(half_w, half_h)
	var fx := (p.x / half_w + p.y / half_h) * 0.5
	var fy := (p.y / half_h - p.x / half_w) * 0.5
	return Vector2i(floori(fx + 0.5), floori(fy + 0.5))


## Chave de profundidade usada para ordenar desenho (trás para frente).
static func depth_key(world_pos: Vector3i) -> int:
	return (world_pos.x + world_pos.y) * 64 + world_pos.z


## Empurrãozinho no Y-Sort para um objeto ficar à frente do PRÓPRIO tile.
##
## Tudo divide um único espaço de Y-Sort, e dentro de uma célula a ordem é:
##   superfície (pivô 0) -> objeto (este viés) -> parede frontal (meia altura).
## O viés precisa ser maior que zero, para o objeto não empatar com a superfície
## em que pisa, e menor que meia altura de tile, para a próxima diagonal (que
## fica meia altura adiante) continuar cobrindo o objeto. Um quarto do tile fica
## exatamente no meio dessa faixa.
func prop_sort_bias() -> float:
	return float(tile_size.y) * 0.25
