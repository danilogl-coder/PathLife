## Bateria de testes do módulo de mundo procedural.
##
## Uso:
##   godot --headless --path . --script res://tests/world_generation_test.gd
extends SceneTree

var _passed := 0
var _failed := 0


func _init() -> void:
	_test_chunk_math()
	_test_iso_matches_tilemap()
	_test_movement_rules()
	_test_biome_scoring()
	_test_terrain_adapter()
	_test_determinism()
	_test_no_seams_between_chunks()
	_test_generation_pipeline()
	_test_structure_planner_is_region_stable()
	_test_navigation()
	_test_save_patches()
	_test_depth_sorting_setup()

	print("\n==== %d passaram, %d falharam ====" % [_passed, _failed])
	quit(1 if _failed > 0 else 0)


## Trava de regressão da ORDENAÇÃO DE PROFUNDIDADE.
##
## Se alguém voltar a colocar o deslocamento de altura na posição do nó (ou
## trocar o sinal do texture_origin), o mundo volta a desenhar terreno alto por
## cima do jogador — e/ou de cabeça para baixo. Estes testes pegam isso.
func _test_depth_sorting_setup() -> void:
	print("\n[Profundidade] alternativas de tile por altura")
	var settings := _settings()
	var catalog: TileCatalog = load("res://data/world/tiles/ground_catalog.tres")
	var source: TileSetAtlasSource = catalog.tile_set.get_source(0)
	var entry := catalog.find(&"campo")
	_check(entry != null, "catalogo resolve o chao campo")

	var ok_origin := true
	var ok_sort := true
	var art_offset := -5
	for level in [settings.min_height, -1, 0, 1, settings.max_height]:
		var alternative := catalog.alternative_for(level)
		if not source.has_alternative_tile(entry.atlas_coords, alternative):
			ok_origin = false
			continue
		var data := source.get_tile_data(entry.atlas_coords, alternative)
		# POSITIVO: texture_origin é subtraído na hora de desenhar, então é
		# assim que o bloco sobe na tela conforme o nível aumenta.
		if data.texture_origin != Vector2i(0, art_offset + level * settings.height_pixels):
			ok_origin = false
		if data.y_sort_origin != level:
			ok_sort = false
	_check(ok_origin, "texture_origin sobe o bloco conforme o nivel")
	_check(ok_sort, "y_sort_origin empilha a coluna da celula na ordem certa")

	# A chave de ordenação NÃO pode depender da altura: é isso que faz terreno
	# alto atrás do jogador parar de cobri-lo.
	var iso := IsoCoordinateSystem.from_settings(settings)
	var flat_a := iso.cell_to_local(Vector2i(4, 7))
	var flat_b := iso.cell_to_local(Vector2i(4, 7))
	_check(flat_a == flat_b, "posicao plana e estavel")
	var low := iso.world_to_local(Vector3i(4, 7, 0))
	var high := iso.world_to_local(Vector3i(4, 7, 6))
	_check(low.y > high.y, "altura maior desenha mais acima na tela")
	_check(is_equal_approx(flat_a.y, low.y), "plano == nivel 0")
	_check(iso.prop_sort_bias() > float(settings.max_height),
		"vies de objetos maior que o maior y_sort_origin de tile",
		"%f vs %d" % [iso.prop_sort_bias(), settings.max_height])
	_check(iso.prop_sort_bias() < float(settings.tile_size.y) * 0.5,
		"vies de objetos menor que meia celula")

	# Sombreamento por altura precisa dar contraste entre patamares vizinhos.
	var here := settings.tint_for_level(3, 3)
	var below := settings.tint_for_level(2, 3)
	var above := settings.tint_for_level(4, 3)
	_check(here == Color.WHITE, "o nivel do jogador fica com a cor original", str(here))
	_check(below.v < 1.0 and above.v < 1.0, "niveis acima e abaixo recebem sombreamento")
	_check(below.v < above.v, "abaixo escurece mais que acima")
	_check(1.0 - below.v > 0.05, "contraste entre niveis vizinhos e perceptivel",
		"delta %f" % (1.0 - below.v))

	# Só a arte fornecida anima.
	var animated := 0
	var static_tiles := 0
	for row in 12:
		var coords := Vector2i(0, row)
		if source.get_tile_animation_frames_count(coords) > 1:
			animated += 1
		else:
			static_tiles += 1
	_check(animated == 6, "somente os 6 tiles fornecidos animam", "%d animados" % animated)
	_check(static_tiles == 6, "os 6 blocos de terra derivados sao estaticos")

	# Cada bioma precisa de um bloco de terra proprio catalogado.
	var resolver_check: BiomeResolver = load("res://data/world/biome_resolver.tres")
	var walls_ok := true
	for biome in resolver_check.biomes:
		if biome.wall_id == &"" or not catalog.has(biome.wall_id):
			walls_ok = false
		if biome.wall_id == biome.ground_id:
			walls_ok = false
	_check(walls_ok, "cada bioma tem bloco de terra proprio embaixo da grama")


func _check(condition: bool, label: String, detail: String = "") -> void:
	if condition:
		_passed += 1
		print("  ok   %s" % label)
	else:
		_failed += 1
		printerr("  FALHA %s %s" % [label, detail])


func _settings() -> WorldSettings:
	var settings: WorldSettings = load("res://data/world/world_settings.tres")
	return settings.duplicate(true)


# ---------------------------------------------------------------------------
func _test_chunk_math() -> void:
	print("\n[ChunkMath] coordenadas negativas")
	var size := 32
	_check(ChunkMath.world_to_chunk(Vector2i(-1, -1), size) == Vector2i(-1, -1), "chunk de (-1,-1)")
	_check(ChunkMath.world_to_local(Vector2i(-1, -1), size) == Vector2i(31, 31), "local de (-1,-1)")
	_check(ChunkMath.world_to_chunk(Vector2i(0, 0), size) == Vector2i(0, 0), "chunk de (0,0)")
	_check(ChunkMath.world_to_local(Vector2i(33, -33), size) == Vector2i(1, 31), "local de (33,-33)")
	var round_trip := ChunkMath.chunk_local_to_world(
		ChunkMath.world_to_chunk(Vector2i(-70, 45), size),
		ChunkMath.world_to_local(Vector2i(-70, 45), size),
		size
	)
	_check(round_trip == Vector2i(-70, 45), "ida e volta world->chunk->world")
	_check(ChunkMath.chunk_to_region(Vector2i(-1, 0), 4) == Vector2i(-1, 0), "chunk -> regiao")


func _test_iso_matches_tilemap() -> void:
	print("\n[Isometria] IsoCoordinateSystem x TileMapLayer")
	var settings := _settings()
	var iso := IsoCoordinateSystem.from_settings(settings)
	var layer := TileMapLayer.new()
	layer.tile_set = load("res://data/world/tiles/ground_tileset.tres")
	var all_match := true
	var sample := Vector2i.ZERO
	for cell: Vector2i in [Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(-3, 5), Vector2i(7, -2)]:
		if layer.map_to_local(cell) != iso.cell_to_local(cell):
			all_match = false
			sample = cell
	_check(all_match, "map_to_local == cell_to_local", "divergiu em %s" % sample)

	var back_ok := true
	for cell: Vector2i in [Vector2i(0, 0), Vector2i(4, 9), Vector2i(-6, -7)]:
		if iso.local_to_cell(iso.cell_to_local(cell)) != cell:
			back_ok = false
	_check(back_ok, "local_to_cell inverte cell_to_local")

	var high := iso.world_to_local(Vector3i(3, 3, 4))
	var low := iso.world_to_local(Vector3i(3, 3, 0))
	_check(is_equal_approx(low.y - high.y, 4.0 * settings.height_pixels), "altura Z desloca no eixo Y")
	layer.free()


func _test_movement_rules() -> void:
	print("\n[MovementRules] regras de degrau")
	var T := MovementRules.MovementTransition
	_check(MovementRules.evaluate(0, 0, true) == T.WALK, "mesma altura anda")
	_check(MovementRules.evaluate(0, 1, true) == T.STEP_UP, "+1 sobe")
	_check(MovementRules.evaluate(0, -1, true) == T.STEP_DOWN, "-1 desce")
	_check(MovementRules.evaluate(0, 2, true) == T.BLOCKED, "+2 bloqueado")
	_check(MovementRules.evaluate(0, -3, true) == T.FALL, "-3 e queda")
	_check(MovementRules.evaluate(0, -99, true) == T.BLOCKED, "queda absurda bloqueia")
	_check(MovementRules.evaluate(0, 0, false) == T.BLOCKED, "destino nao caminhavel bloqueia")
	_check(MovementRules.evaluate(0, 0, true, true) == T.BLOCKED, "agua bloqueia quem nao nada")

	var swimmer := MovementContext.new()
	swimmer.can_swim = true
	swimmer.max_step_up = 3
	_check(MovementRules.evaluate(0, 0, true, true, swimmer) == T.SWIM, "contexto permite nadar")
	_check(MovementRules.evaluate(0, 3, true, false, swimmer) == T.STEP_UP, "contexto permite +3")


func _test_biome_scoring() -> void:
	print("\n[Biomas] pontuacao e transicao")
	_check(is_equal_approx(BiomeResolver.range_score(0.5, 0.4, 0.6, 0.1), 1.0), "dentro da faixa = 1")
	_check(is_equal_approx(BiomeResolver.range_score(0.35, 0.4, 0.6, 0.1), 0.5), "meia transicao = 0.5")
	_check(is_equal_approx(BiomeResolver.range_score(0.2, 0.4, 0.6, 0.1), 0.0), "fora da transicao = 0")

	var resolver: BiomeResolver = load("res://data/world/biome_resolver.tres")
	_check(resolver.biomes.size() == 6, "um bioma para cada tile de grama fornecido")
	var reachable: Dictionary = {}
	for ti in 21:
		for hi in 21:
			for ci in [0.15, 0.36, 0.6, 0.95]:
				var sample := ClimateSample.new()
				sample.temperature = ti / 20.0
				sample.humidity = hi / 20.0
				sample.continentalness = ci
				var resolution := resolver.resolve(sample)
				if resolution.primary != null:
					reachable[resolution.primary.id] = true
	_check(reachable.size() == resolver.biomes.size(), "todos os biomas sao alcancaveis",
		str(reachable.keys()))


func _test_terrain_adapter() -> void:
	print("\n[TerrainAdapter] mistura de altura")
	_check(is_equal_approx(TerrainAdapter.blend_height(10.0, 4.0, 0.0, 5.0), 4.0), "no footprint vira alvo")
	_check(is_equal_approx(TerrainAdapter.blend_height(10.0, 4.0, 5.0, 5.0), 10.0), "no fim da margem mantem")
	var mid := TerrainAdapter.blend_height(10.0, 4.0, 2.5, 5.0)
	_check(mid > 4.0 and mid < 10.0, "no meio interpola", str(mid))
	var rect := Rect2i(Vector2i(4, 4), Vector2i(4, 4))
	_check(is_equal_approx(TerrainAdapter.distance_to_rect(Vector2i(5, 5), rect), 0.0), "dentro = 0")
	_check(is_equal_approx(TerrainAdapter.distance_to_rect(Vector2i(9, 5), rect), 2.0), "2 celulas fora")


func _build_generator(settings: WorldSettings, world_seed: int) -> WorldGenerator:
	var source: WorldGenerator = load("res://data/world/world_generator.tres")
	var generator := source.clone()
	generator.prepare(settings, world_seed)
	return generator


func _test_determinism() -> void:
	print("\n[Determinismo] mesma semente = mesmo chunk")
	var settings := _settings()
	var a := _build_generator(settings, 12345)
	var b := _build_generator(settings, 12345)
	var c := _build_generator(settings, 999)

	var chunk_a := a.generate_chunk(Vector2i(-3, 2))
	var chunk_b := b.generate_chunk(Vector2i(-3, 2))
	var chunk_c := c.generate_chunk(Vector2i(-3, 2))

	var identical := true
	var different := false
	for i in chunk_a.cells.size():
		if chunk_a.cells[i].height != chunk_b.cells[i].height:
			identical = false
		if chunk_a.cells[i].biome_id != chunk_b.cells[i].biome_id:
			identical = false
		if chunk_a.cells[i].height != chunk_c.cells[i].height:
			different = true
	_check(identical, "mesma semente reproduz o chunk")
	_check(different, "semente diferente muda o mundo")

	var again := a.generate_chunk(Vector2i(-3, 2))
	var stable := true
	for i in chunk_a.cells.size():
		if again.cells[i].height != chunk_a.cells[i].height:
			stable = false
	_check(stable, "regerar o mesmo chunk repete o resultado")


func _test_no_seams_between_chunks() -> void:
	print("\n[Chunks] continuidade nas bordas")
	var settings := _settings()
	var generator := _build_generator(settings, 4242)
	var left := generator.generate_chunk(Vector2i(0, 0))
	var right := generator.generate_chunk(Vector2i(1, 0))
	var below := generator.generate_chunk(Vector2i(0, 1))

	var max_step := 0
	for y in settings.chunk_size:
		var a := left.get_cell(Vector2i(settings.chunk_size - 1, y))
		var b := right.get_cell(Vector2i(0, y))
		max_step = maxi(max_step, absi(a.height - b.height))
	for x in settings.chunk_size:
		var a := left.get_cell(Vector2i(x, settings.chunk_size - 1))
		var b := below.get_cell(Vector2i(x, 0))
		max_step = maxi(max_step, absi(a.height - b.height))
	# Um degrau grande na costura significaria ruido em coordenada local.
	_check(max_step <= 3, "sem costura de ruido entre chunks", "degrau maximo %d" % max_step)

	var biome_ok := true
	for y in settings.chunk_size:
		var a := left.get_cell(Vector2i(settings.chunk_size - 1, y))
		var b := right.get_cell(Vector2i(0, y))
		if a.biome_id != b.biome_id and a.biome_blend < 0.2 and b.biome_blend < 0.2:
			biome_ok = false
	_check(biome_ok, "biomas nao seguem a borda do chunk")


func _test_generation_pipeline() -> void:
	print("\n[Pipeline] conteudo gerado")
	var settings := _settings()
	var generator := _build_generator(settings, 777)
	var filled := 0
	var heights: Dictionary = {}
	var biomes: Dictionary = {}
	var decorations := 0
	var liquid := 0
	var terrains: Dictionary = {}

	for cy in range(-2, 3):
		for cx in range(-2, 3):
			var chunk := generator.generate_chunk(Vector2i(cx, cy))
			decorations += chunk.decorations.size()
			for cell in chunk.cells:
				if cell == null:
					continue
				filled += 1
				heights[cell.height] = true
				biomes[cell.biome_id] = true
				terrains[cell.terrain_id] = true
				if cell.is_liquid():
					liquid += 1
				if cell.height < settings.min_height or cell.height > settings.max_height:
					_failed += 1

	_check(filled == 25 * settings.chunk_size * settings.chunk_size, "todas as celulas preenchidas")
	_check(heights.size() >= 5, "relevo variado", "%d alturas" % heights.size())
	_check(biomes.size() >= 2, "mais de um bioma na amostra", str(biomes.keys()))
	_check(terrains.size() >= 2, "mais de um tipo de relevo", str(terrains.keys()))
	_check(decorations > 0, "vegetacao gerada", "%d decoracoes" % decorations)
	print("     (agua em %d celulas, alturas %s)" % [liquid, str(heights.keys().size())])


func _test_structure_planner_is_region_stable() -> void:
	print("\n[Estruturas] planejamento por regiao")
	var settings := _settings()
	var planner: StructurePlanner = load("res://data/world/structure_planner.tres").duplicate(true)
	planner.sampler = planner.sampler.duplicate(true)
	planner.sampler.prepare(settings, 2026)
	planner.clear_cache()

	var first := planner.plan_region(Vector2i(0, 0), settings, 2026)
	planner.clear_cache()
	var second := planner.plan_region(Vector2i(0, 0), settings, 2026)
	var same := first.size() == second.size()
	if same:
		for i in first.size():
			if first[i].origin_xy != second[i].origin_xy:
				same = false
			if first[i].foundation_height != second[i].foundation_height:
				same = false
	_check(same, "regiao replaneja identica")

	# Uma estrutura na borda deve aparecer no plano dos dois chunks vizinhos,
	# mas ser instanciada apenas uma vez.
	var generator := _build_generator(settings, 2026)
	var instantiated: Dictionary = {}
	var duplicated := false
	for cy in range(-3, 4):
		for cx in range(-3, 4):
			var chunk := generator.generate_chunk(Vector2i(cx, cy))
			for placement in chunk.structures:
				if instantiated.has(placement.origin_xy):
					duplicated = true
				instantiated[placement.origin_xy] = true
	_check(not duplicated, "estrutura nunca instanciada duas vezes")
	print("     (%d estruturas em 7x7 chunks)" % instantiated.size())

	# O terreno deve estar plano sob o footprint.
	var flat_ok := true
	var checked := 0
	for cy in range(-3, 4):
		for cx in range(-3, 4):
			var chunk := generator.generate_chunk(Vector2i(cx, cy))
			for placement in chunk.structures:
				checked += 1
				for y in placement.definition.footprint.y:
					for x in placement.definition.footprint.x:
						var cell := chunk.get_cell_world(placement.origin_xy + Vector2i(x, y))
						if cell != null and cell.height != placement.foundation_height:
							flat_ok = false
	_check(flat_ok, "terreno adaptado ao footprint", "%d estruturas verificadas" % checked)


func _test_navigation() -> void:
	print("\n[Navegacao] A* usa as MovementRules")
	var settings := _settings()
	var sampler: WorldSampler = load("res://data/world/world_sampler.tres").duplicate(true)
	sampler.prepare(settings, 555)
	var generator := _build_generator(settings, 555)
	var world := WorldData.new(settings, sampler)
	for cy in range(-1, 2):
		for cx in range(-1, 2):
			world.add_chunk(generator.generate_chunk(Vector2i(cx, cy)))

	var navigation := WorldNavigation.new(world, load("res://data/world/player_movement_context.tres"))
	var start := Vector2i.ZERO
	# Procura um ponto de partida caminhável.
	for radius in 12:
		var found := false
		for y in range(-radius, radius + 1):
			for x in range(-radius, radius + 1):
				if world.is_walkable(Vector2i(x, y)):
					start = Vector2i(x, y)
					found = true
					break
			if found:
				break
		if found:
			break

	var reachable := navigation.neighbors(start)
	_check(reachable.size() > 0, "celula inicial tem vizinhos caminhaveis")

	var goal := start
	var path: Array[Vector3i] = []
	for attempt in 24:
		var candidate := start + Vector2i(attempt - 12, 6)
		if not world.is_walkable(candidate):
			continue
		path = navigation.find_path(start, candidate)
		if path.size() > 1:
			goal = candidate
			break
	_check(path.size() > 1, "encontrou um caminho", "de %s ate %s" % [start, goal])

	var legal := true
	for i in range(1, path.size()):
		var from := Vector2i(path[i - 1].x, path[i - 1].y)
		var to := Vector2i(path[i].x, path[i].y)
		if not MovementRules.allows_movement(MovementRules.evaluate_world(world, from, to, null)):
			legal = false
		if absi(path[i].z - path[i - 1].z) > 1:
			legal = false
	_check(legal, "todo passo do caminho respeita as regras")


func _test_save_patches() -> void:
	print("\n[Save] semente + diferencas")
	var settings := _settings()
	var generator := _build_generator(settings, 31337)
	var chunk := generator.generate_chunk(Vector2i(0, 0))
	var target := chunk.get_cell(Vector2i(3, 3))
	var original_height := target.height

	var manager := WorldSaveManager.new()
	manager.save_path = "user://__test_world_save.json"
	manager.set_seed(31337)
	var patch := CellPatch.new()
	patch.world_pos = Vector3i(3, 3, 0)
	patch.height_override = original_height + 5
	patch.ground_override = &"pedra"
	manager.patch_cell(patch)
	if not chunk.decorations.is_empty():
		manager.remove_object(chunk.decorations[0].object_id)
	var decorations_before := chunk.decorations.size()
	_check(manager.save() == OK, "gravou o save")

	var reloaded := WorldSaveManager.new()
	reloaded.save_path = "user://__test_world_save.json"
	_check(reloaded.load_seed(0) == 31337, "semente persistiu")

	var regenerated := generator.generate_chunk(Vector2i(0, 0))
	reloaded.apply_patches(regenerated)
	var patched := regenerated.get_cell(Vector2i(3, 3))
	_check(patched.height == original_height + 5, "altura alterada persistiu")
	_check(patched.ground_id == &"pedra", "chao alterado persistiu")
	if decorations_before > 0:
		_check(
			regenerated.decorations.size() == decorations_before - 1,
			"objeto removido nao volta"
		)
	DirAccess.remove_absolute(ProjectSettings.globalize_path("user://__test_world_save.json"))
	manager.free()
	reloaded.free()
